# Full protocol configuration
methods_dict <- list(
  RMP = list(
    prior_weight = list(
      range = seq(0, 1, length.out = 11),
      parameter_name = "Prior weight",
      parameter_label = "w",
      parameter_notation = "$w$",
      type = "continuous",
      important_values = c(0.2, 0.5, 0.8),
      reference_values = c(0.5),
      is_updated = TRUE
    ),
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    ),
    empirical_bayes = list(
      range = list(TRUE),
      parameter_name = "Empirical Bayes",
      parameter_label = "EB",
      parameter_notation = "EB",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  NPP = list(
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    ),
    power_parameter_mean = list(
      range = list(0.5),
      parameter_name = "Power parameter prior mean",
      parameter_label = "xi_gamma",
      parameter_notation = "$\\xi_\\gamma$",
      type = "continuous",
      important_values = c(0.5),
      reference_values = c(0.5),
      is_updated = FALSE,
      display = TRUE
    ),
    power_parameter_std = list(
      range = list(0.1, 0.2, 0.4),
      parameter_name = "Power parameter prior std",
      parameter_label = "sigma_gamma",
      parameter_notation = "$\\sigma_\\gamma$",
      type = "continuous",
      important_values = c(0.1, 0.2, 0.4),
      reference_values = c(0.2),
      is_updated = FALSE,
      display = TRUE
    )
  ),
  separate = list(
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  pooling = list(
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  conditional_power_prior = list(
    power_parameter = list(
      range = seq(0, 1, length.out = 5),
      parameter_name = "Power prior parameter",
      parameter_label = "gamma",
      parameter_notation = "$\\gamma$",
      type = "continuous",
      important_values = c(0.25, 0.5, 0.75),
      reference_values = c(0.5),
      is_updated = FALSE
    ),
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  GaussianElasticPriorLogistic = list(
    shape_param = list(
      range = c(1),
      parameter_name = "k",
      parameter_label = "k",
      parameter_notation = "$k$",
      type = "continuous",
      is_updated = FALSE
    ),
    clinically_meaningful_diff = list(
      range = c(1),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    percentile_homogeneous = list(
      range = c(0.95),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    percentile_heterogeneous = list(
      range = c(0.02),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    value_elastic_homogeneous = list(
      range = c(0.99),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    value_elastic_heterogeneous = list(
      range = c(0.01),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    num_simulations = list(
      range = c(50000),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    initial_prior = list(
      range = c("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    ),
    efficacy_cutoff = list(
      range = c(0.918),
      parameter_name = "Efficacy cutoff",
      parameter_label = "Efficacy cutoff",
      parameter_notation = "Efficacy cutoff",
      type = "continuous",
      is_updated = FALSE
    ),
    w1 = list(
      range = c(0.2, 1, 5),
      parameter_name = "w1",
      parameter_label = "w1",
      parameter_notation = "$w_1$",
      type = "continuous",
      is_updated = FALSE
    ),
    w2 = list(
      range = c(0.2, 1, 5),
      parameter_name = "w2",
      parameter_label = "w2",
      parameter_notation = "$w_2$",
      type = "continuous",
      is_updated = FALSE
    ),
    eta = list(
      range = c(0.2, 0.2, 0.5),
      parameter_name = "eta",
      parameter_label = "eta",
      parameter_notation = "$\\eta$",
      type = "continuous",
      is_updated = FALSE
    )
  ),
  GaussianElasticPriorStep = list(
    num_simulations = list(
      range = c(50000),
      parameter_name = NULL,
      parameter_label = NULL,
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    ),
    initial_prior = list(
      range = c("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    ),
    w1 = list(
      range = c(0.2, 1, 5),
      parameter_name = "w1",
      parameter_label = "w1",
      parameter_notation = "$w_1$",
      type = "continuous",
      is_updated = FALSE
    ),
    w2 = list(
      range = c(0.2, 1, 5),
      parameter_name = "w2",
      parameter_label = "w2",
      parameter_notation = "$w_2$",
      type = "continuous",
      is_updated = FALSE
    ),
    eta = list(
      range = c(0.2, 0.2, 0.5),
      parameter_name = "Success probability threshold",
      parameter_label = "Success probability threshold",
      parameter_notation = "$\\eta$",
      type = "continuous",
      is_updated = FALSE
    ),
    congruence_quantile = list(
      range = c(0.987),
      parameter_name = "Congruence quantile",
      parameter_label = "Congruence quantile",
      parameter_notation = NULL,
      type = "continuous",
      is_updated = FALSE
    )
  ),
  p_value_based_PP = list(
    shape_parameter = list(
      range = list(0.01, 0.1, 1, 10, 20),
      parameter_name = "Shape parameter",
      parameter_label = "k",
      parameter_notation = "$k$",
      type = "continuous",
      important_values = c(1),
      is_updated = FALSE
    ),
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    ),
    equivalence_margin = list(
      range = list(0.1, 0.5),
      parameter_name = "lambda",
      parameter_label = "lambda",
      parameter_notation = "$\\lambda$",
      type = "continuous",
      important_values = c(0.5),
      is_updated = FALSE
    )
  ),
  PDCCPP = list(
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    ),
    desired_tie = list(
      range = list(0.065),
      parameter_name = "Desired TIE",
      parameter_label = "desired_tie",
      parameter_notation = "Desired TIE",
      type = "continuous",
      important_values = c(0.065),
      reference_values = c(0.065),
      is_updated = FALSE
    ),
    significance_level = list(
      range = list(0.05),
      parameter_name = "Significance level",
      parameter_label = "sig",
      parameter_notation = "Significance level",
      type = "continuous",
      important_values = c(0.05),
      reference_values = c(0.05),
      is_updated = FALSE
    ),
    tolerance = list(
      range = list(0.0001),
      parameter_name = "Tolerance",
      parameter_label = "tol",
      parameter_notation = "Tolerance",
      type = "continuous",
      important_values = c(0.0001),
      reference_values = c(0.0001),
      is_updated = FALSE
    ),
    n_iter = list(
      range = list(1e6),
      parameter_name = "Number of iterations",
      parameter_label = "n_iter",
      parameter_notation = "Number of iterations",
      type = "integer",
      important_values = c(1e6),
      reference_values = c(1e6),
      is_updated = FALSE
    )
  ),
  EB_PP = list(
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  test_then_pool_difference = list(
    significance_level = list(
      range = list(0.01, 0.1, 0.4, 0.8),
      parameter_name = "eta",
      parameter_label = "eta",
      parameter_notation = "$\\eta$",
      type = "continuous",
      important_values = c(0.1, 0.4),
      reference_values = c(0.1),
      is_updated = FALSE
    ),
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  test_then_pool_equivalence = list(
    significance_level = list(
      range = list(0.1, 0.5),
      parameter_name = "eta",
      parameter_label = "eta",
      parameter_notation = "$\\eta$",
      type = "continuous",
      important_values = c(0.5),
      reference_values = c(0.5),
      is_updated = FALSE
    ),
    equivalence_margin = list(
      range = list(0.1, 0.5, 0.8),
      parameter_name = "lambda",
      parameter_label = "lambda",
      parameter_notation = "$\\lambda$",
      type = "continuous",
      important_values = c(0.5),
      reference_values = c(0.5),
      is_updated = FALSE
    ),
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  ),
  commensurate_power_prior = list(
    heterogeneity_prior = list(
      range = list(
        list(family = "inverse_gamma", alpha = 1 / 3, beta = 1),
        list(family = "inverse_gamma", alpha = 1 / 7, beta = 1),
        list(family = "inverse_gamma", alpha = 1 / 1000, beta = 1),
        list(family = "half_normal", std_dev = 1),
        list(family = "half_normal", std_dev = 5)
        # list(family = "cauchy", location = 0, scale = 10)
      ),
      parameter_name = "Heterogeneity prior",
      parameter_label = "tau",
      parameter_notation = "$\\tau$",
      type = "categorical",
      important_values = list(family = "inverse_gamma", alpha = 1 / 7, beta = 1),
      reference_values = list(family = "inverse_gamma", alpha = 1 / 7, beta = 1),
      is_updated = FALSE
    ),
    initial_prior = list(
      range = list("noninformative"),
      parameter_name = "Initial prior",
      parameter_label = "pi_0",
      parameter_notation = "$\\pi_0$",
      type = "categorical",
      is_updated = FALSE
    )
  )
)

methods_labels <- list(
  RMP = list(
    full_name = "Robust Mixture Prior",
    short_name = "RMP",
    label = "RMP"
  ),
  separate = list(
    full_name = "Separate analysis",
    short_name = "Separate",
    label = "Separate"
  ),
  pooling = list(
    full_name = "Pooling",
    short_name = "Pooling",
    label = "Pooling"
  ),
  conditional_power_prior = list(
    full_name = "Conditional Power Prior",
    short_name = "conditional_power_prior",
    label = "Conditional Power Prior"
  ),
  commensurate_power_prior = list(
    full_name = "Commensurate Power Prior",
    short_name = "commensurate_power_prior",
    label = "Commensurate Power Prior"
  ),
  NPP = list(
    full_name = "Normalized Power Prior",
    short_name = "NPP",
    label = "NPP"
  ),
  PDCCPP = list(
    full_name = "Prior-Data Conflict Calibrated Power Prior",
    short_name = "PDCCPP",
    label = "PDCCPP"
  ),
  EB_PP = list(
    full_name = "Empirical Bayes Power Prior",
    short_name = "EB_PP",
    label = "EBPP"
  ),
  elastic_prior = list(
    full_name = "Elastic prior",
    short_name = "EP",
    label = "Elastic Prior"
  ),
  p_value_based_PP = list(
    full_name = "p-value-based Power Prior",
    short_name = "pPP",
    label = "p-value-based PP"
  ),
  test_then_pool_difference = list(
    full_name = "Test-then-pool difference",
    short_name = "TtP diff",
    label = "Test-then-pool (difference)"
  ),
  test_then_pool_equivalence = list(
    full_name = "Test-then-pool equivalence",
    short_name = "TtP eq",
    label = "Test-then-pool (equivalence)"
  )
)
