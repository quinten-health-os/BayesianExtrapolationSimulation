devtools::load_all()

# Load required libraries
library(tidyverse)
library(readr)
library(ggplot2)
library(RBExT)


env <- "full"
config_dir <- paste0(system.file(paste0("conf/", env), package = "RBExT"), "/")

results_dir <- paste0("./results/", env)

tables_dir <<- paste0("./tables/", env, "_tables")

case_studies_config_dir <- paste0(system.file(paste0("conf/case_studies"), package = "RBExT"), "/")
source(system.file(paste0("conf/plots_config.R"), package = "RBExT"))
source(system.file(paste0("conf/metrics_config.R"), package = "RBExT"))

source(paste0(config_dir, "methods_config.R"))

results_freq_df <- readr::read_csv(paste0(results_dir, "/results_frequentist.csv"))
results_bayes_df <- readr::read_csv(paste0(results_dir, "/results_bayesian_simpson.csv"))

table_methods_comparison(results_freq_df, frequentist_metrics)

table_bayesian_ocs(results_bayes_df, bayesian_metrics)

power_vs_tie_tables(results_freq_df, frequentist_metrics)

tables_metric_vs_scenario(results_freq_df, frequentist_metrics)

posterior_parameters_tables(results_freq_df, frequentist_metrics)
