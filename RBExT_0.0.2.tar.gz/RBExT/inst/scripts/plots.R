devtools::load_all()
library(RBExT)
# Load required libraries
library(tidyverse)
library(readr)
library(ggplot2)
library(extrafont)
library(tikzDevice)
library(grid)

env <- "full"

results_dir <- paste0("./results/", env)
config_dir <- paste0(system.file(paste0("conf/", env), package = "RBExT"), "/")
case_studies_config_dir <- paste0(system.file(paste0("conf/case_studies"), package = "RBExT"), "/")

figures_dir <<- paste0("./figures/", env, "_figures/")

source(system.file(paste0("conf/plots_config.R"), package = "RBExT"))

source(system.file(paste0("conf/metrics_config.R"), package = "RBExT"))

source(paste0(config_dir, "methods_config.R"))

results_freq_df <- readr::read_csv(paste0(results_dir, "/results_frequentist.csv"))
results_bayes_df <- readr::read_csv(paste0(results_dir, "/results_bayesian_simpson.csv"))

# Filter the results with the methods we are interest in:
results_freq_df <- subset(results_freq_df, method %in% c("conditional_power_prior", "EB_PP", "p_value_based_PP", "PDCCPP", "pooling", "RMP", "separate", "test_then_pool_difference", "test_then_pool_equivalence", "NPP", "commensurate_power_prior"))

results_bayes_df <- subset(results_bayes_df, method %in% c("conditional_power_prior", "EB_PP", "p_value_based_PP", "PDCCPP", "pooling", "RMP", "separate", "test_then_pool_difference", "test_then_pool_equivalence", "NPP", "commensurate_power_prior"))

forest_plot_methods_comparison(results_freq_df, inference_metrics)
forest_plot_methods_comparison(results_freq_df, frequentist_metrics)
forest_plot_methods_comparison_bayesian(results_bayes_df, bayesian_metrics)

plot_success_proba_vs_scenario(results_freq_df, frequentist_metrics)

plot_metric_vs_scenario(results_freq_df, frequentist_metrics)
plot_metric_vs_scenario(results_freq_df, inference_metrics)

plot_metrics_vs_ess(results_freq_df, frequentist_metrics, inference_metrics)

posterior_parameters_plots(results_freq_df)

power_vs_tie_plots(results_freq_df, frequentist_metrics)

bayesian_ocs_plots(results_bayes_df, bayesian_metrics)
