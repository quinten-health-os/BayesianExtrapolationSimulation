# Project to-do list

[x] Visualization of Bayesian OCs

[x] Harmonize figures styles through configuration

[x] Change data generation and SE computation for the Teriflunomide case study to take censoring into account

[x] For MCMC models: Make different functions for sampling the prior and the posterior (when computing Bayesian OCs) (see vignette about the truncated normal RMP for a template)

[x] Implement the power prior in the binary case -> double check the implementation

[x] Debug PDCCPP, EBPP, PTtP

[x] Stavros's code assumed that the sampling variance is the same in the source and target study, so we have to adapt it to our case.

[x] Edit replication vignettes to show how we do not need drift in treatment effect.

[x] Debug data generation in the Teriflunomide case study

[x] Use a Gaussian likelihood for PDCCPP in the aprepitant case

[x] Add conditions to check the initial prior is implemented (see my NPP implementation)

[x] Test the computation of Bayesian OCs

[x] Implement the p-value based PP in the binary case -> Use the same test as in the Gaussian likelihood case

[x] Power of the frequentist test for non-gaussian likelihoods (operating_characteritics.R) -> We use a z or t test anyway

[x] Vary the denominator in the source study when the summary statistics is a ratio -> at constant source TE

[x] Check that the target_ESS is reached by MCMC

[x] Checks and diagnostics for MCMC models

[x] When using test-then-pool, PDCCPP, PTtP, etc, I use self$prior$source$source_total_sample_size -> This should not be the case (since the number of subjects can be different in each arm)

[x] Parallelization for Bayesian OCs

[x] Harmonize figures styles through configuration

[x] Pr(study success) vs drift for different denominator values : study the effect of changes in the denominator

[x] Add a condition for whether we compute frequentist ocs or not.

[x] When plotting the results, dplyr::filter on denominator factor

[x] Use analytic estimation of SE for Mepolizumab

[x] Include the ESS in the metrics to plot

[x] Add horizontal jitter in the plots of OCs

[x] Generalize forest_plot_methods_comparison to other metrics

[x] Rationalize models organization across files

[x] Sweet spot computation

[x] Tests for the pipeline

[x] Include vignettes in the tests

[x] Add tests for the analysis code

[x] Save one file per case_study + method

[x] Make code deployment-ready + update README

[x] Numerical stability RMP

[x] Solve file paths issues for plots and tables

[x] Implement the Commensurate PP

[x] Join points in plots of Bayesian OCs

[x] Option decimal vs scientific notation in tables

[x] "Therefore, we will include an additional simulation scenario for the case studies with continuous endpoints (Botox and Dapagliflozin) where the simulated variance in the paediatric data is two times larger than the variance observed in adults." -> Maybe do not include this

[x] Add prefixes to file names

[x] To remove functions from the reference in the doc: #' @keywords internal

[x] Increase the number of samples to estimate the CrI and set it as a simulation_config parameter

[x] Add integration tests to the README

[x] When packaging the code: make sure that the scripts also work

[x] Improve plots functions organization

[x] In the plots and tables, filter on target_to_source_std_ratio

[x] Plots to study the effect of changes in the denominator of summary measures

[x] Plot the effect of changing target_to_source_std_ratio

[x] Debug remaining vignettes

[x] Explain in simulation vignettes how the source denominator is loaded

[x] Understand why test_then_pool_equivalence is so slow -> It was due to posterior_to_RBesT. -> Methods that end up using a Gaussian can be optimize when computing ESS

[x] Put all Bayesian metrics in a single table/classify by design prior

[x] Remove the control drift and treatment drift from the vignettes

[x] Results tables

[x] Change the way I filter on important drift values

[x] Check tables and plots for methods with multiple parameters

[x] - PDCCPP #-> Null space - predictive_test_then_pool # -> Null space

[x] Make sure that methods (PDCCP, etc) that rely on theta_0 (sometimes implicitly), can handle theta_0 != 0. -> checklist + corrections

[x] Test Bayesian OCs for newly implemented methods

[x] Make PDCCPP, EBPP handle right-sided null hypotheses

[x] Use RBesT for Separate and Pooling  

[x] Make sure to compare methods with equivalent hypotheses (for example, PDCCPP and PTtP assume that the variance is known, which is not the case of all other methods). Moreover, the PDCPP§PTtP assumes that the sampling variance is the same in the source and target study.

[x] Explore different methods for Bayesian OCs estimation

[x] Implement the ElasticPrior : use the code provided in
https://onlinelibrary.wiley.com/doi/abs/10.1111/biom.13551

[x] Make code more robust using explicit arguments in function calls

[x] Handling of source sample size in the commensurate PP (use of an equivalent sample size per arm)

[x] equivalent_source_sample_size_per_arm should be a property of the source data (as source_data$sample_size_per_arm) -> Do not redo the computation everywhere

[x] Frequentist test in the aprepitant case? ->  two proportions z test with margin

[x] In the aprepitant case study: we approximate the posterior/prior distributions with a mixture of Beta. This is used to find a unit-information prior (moment-based ESS of 1). However, for precision-based ESS, we match the posterior using a mixture of normal distributions

[x] Implement design priors in the aprepitant case (currently "not implemented for other distributions)")

[x] However, it is not clear which distribution family to use for the matching distribution in the case where the treatment effect is a difference in proportions, given that in that case the support of the distribution is [-1,1]. In a previous email, he suggested two possibilities: either linearly scaling a beta distribution to [-1,1], or use a Gaussian distribution (which would be easier to implement), assuming that the ESS estimation would be good enough as long as most of the probability mass of the matching Gaussian is in the [-1,1] range. JJA suggests using a Gaussian distribution and expects the ESS approximation to be good enough. TF says that this approach will be tested, and the ESS obtained compared with other ESS measures to check consistency.

[x] Solve divergence issues with CPP in the Aprepitant case

[x] Remove the use of "Truncated Gaussian" -> Be more explicit, with the use of a binomial likelihood

[x] Implement the sample_prior method of the Gaussian NPP 
 
[x] Debug blank files issues with forestplots

[x] Use the results from frequentist OCs estimation to compute Bayesian OCs : to do so, increase the drift grid resolution. One issue is that the drift bounds may not be large enough for some priors.

[x] Go through the FIXMEs and TODOs/browser()

[x] For the NPP, we want to return the posterior distribution of the power parameter as well. 

[x] Check processing of posterior parameters : RMP/NPP/p_value_based_PP/PDCCPP/predictive_test_then_pool/EB_PP/test_then_pool (fraction of pools)/commensurate_power_prior

[x] Report in the table the MCMC metrics (rhat, MCMC ESS) when there is an issue with it. 

[x] Commensurate Power Prior in the aprepitant case
 
[x] Debug PDCCPP : in the Dapagliflozin case. 

[x] Debug PDCCPP : in the Aprepitant case. 

[x] Store MCMC informations (ESS, Rhat, N divergences) in the results

[x] Control of Random Number Generation (with parallelization)

[x] Debug commensurate PP in belimumab (MCMC ESS is sometimes NULL)

[x] Investigate the bug with Mepolizumab data generation.

[x] Create a function do display a case study config (for the vignettes)

[x] Try to reduce ndrift and see the impact on Bayesian OCs estimation

[x] Store stan models in the stan folder

[x] Forest plots for other metrics

[x] Update vignettes index in _pkgdown.yml

[x] Optimize Gaussian Commensurate Power Prior

[x] Recompilation of Stan models on AWS. 

[x]'threads_per_chain' is set but the model was not compiled with 'cpp_options = list(stan_threads = TRUE)' so 'threads_per_chain' will have no effect!

[x] Dynamically adapt MCMC chains length

[x] Non-factorial design

[x] I removed parallelization from the scenarios definition(simulation_scenarios.R)

[x] Problem : target_to_source_std_ratio_range <- c(1, 2) is hard coded (should depend on the config)

[x] prior_pdf = function(target_treatment_effect, ...) -> prior_pdf = function(target_treatment_effect) (not sure)

[x] Issue with the prior pdf of the empirical Bayes PP methods

[x] Add the calibration parameter of the PTtP approchas a parameter

[x] Replace strong treatment effect with consistent treatment effect and moderate treatment effect with 
partially consistent. 

[x] Add MCMC visual inspection to vignettes (trace plots and autocorrelation plots)

[x] Comparison with frequentist analyses that use either full borrowing (pooling) or no borrowing (separate)

[x] Check consistency of the rng state across scenarios

[x] For p-value based PP with Aprepitant : Use BinomialSeparate and BinomialPooling. is a ztest.  Change the organization of configuration files accordingly 

[x] Use rootfinding for quantiles estimation, when possible.

[x] Test-then-pool/p-value-based PP: use a t-test instead

[x] Power of the frequentist test in the Aprepitant case

[x] Finish the vs_parameters plots

[x] Handle multiple parameters in Bayesian OCs vs parameters plots

[x] Debug the NPP vignette to plot the power parameter vs drift

[x] Plots as a function of ESS (for easier comparison) -> plot_metric_vs_ess
 
[x] Finish tables 

[x] Report sweet spots

[x] Add CI of Power at equivalent TIE in tables.


### Plots and tables

[x] When plotting Bayesian OC vs parameter (or sample size), for different treatment effects, specify which design prior is used.

[x] Adapt the plots for non-factorial designs

[x] Make sure to add the reference line corresponding to frequentist power in Power vs TIE plots.
 
### Before deployment on Adastra:

[x] Sync the full config with the tests config

[x] Check that the methods configuration (and configuration in general) matches the protocol

[x] Create a new release to tag the version 

### Checklist before code release:

[x] What should I put in the RBexT_package.R file ?

[x] Make vignettes for PDCCPP, EBPP, TtP

[x] Autoformat the code ; use library(styler), then style_dir(). 
Select the code, then use code > Reindent lines/Reformat code (ctr + shift + A, ctrl + I)
Additionally, run RStudio linter (> Addins > Lint Current Package) 

[x] Choose a licence, and modify readme accordingly

[x] Remove commented sections

[x] Deal with warning occurring with devtools::build()

[x] Create reference manual

[x] Add papers references to vignettes (see https://opensource.nibr.com/RBesT/articles/introduction.html)

[x] Plot posterior parameter for commensurate PP (in vignettes)

[x] Add algebra to all the vignettes that describe methods

[x] Deal with multiple parameters in the frequentist OCs vs parameters tables

[x] Update all the vignettes

### For future work:
[~] Unit tests

[] Deal with multiple posterior parameters in posterior param vs prior param (plots and tables)

[x] Add label title to the Design priors for Bayesian OCs plots

[x] Single code for variants of Commensurate PP (no gains in the current split version)

[] Use consistent naming for methods (with Gaussian or Binomial as suffix)

[] Remove target_data$standard_deviation as it is unused and may introduce some confusion (as instead we use target_data$sample$standard_error)

[] When generating data, remove if (self$summary_measure_likelihood == "normal" && self$sampling_approximation == FALSE), since the data generation should not depend on the summary measure likelihood, but on the sampling approximation (which should be either "Gaussian", or something else)

[] Prior predictive checks for models that use Stan

[] Transform data to handle non zero theta and left null hypothesis space in the Model class

[] Create a print_model_summary method for each model 

[] For consistency across methods, use self$parameters$equivalence_margin instead of self$equivalence_margin for all methods.

[] Generalize the code to allow for different sample sizes in the arms of the target study

[] Implement the NPP in the binary case

[] Implement Test then pool in the binary case, without approximation

[x] Write a contribution guide

[] Make the code more robust using private attributes

[] Use source_data$sample as well, for consistency

[] Make the assumption about the known variance more explicit in the code.

[] Make it clear somewhere (in the vignettes) that the sample standard deviation for the generation of target study data corresponds to the sample std in adults for continuous data.

[] Distinguish public/private/active classes elements

[] Change the TargetData class so that it can be defined without source data as input. 

[] Solve warning of the form : replacing previous import ‘jsonlite::unbox’ by ‘rlang::unbox’ when loading ‘RBExT’

[] Change the drift range computation in the Aprepitant case to constrain the number of drift values (instead of filtering)

