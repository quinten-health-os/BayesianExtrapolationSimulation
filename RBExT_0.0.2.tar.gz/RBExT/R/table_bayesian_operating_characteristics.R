#' Generate tables for metrics vs parameters
#'
#' This function creates tables comparing Bayesian metrics against different parameter values for a given case study and method.
#'
#' @param results_metrics_df A data frame containing the results and metrics.
#' @param case_study Character string specifying the case study. Default is "belimumab".
#' @param method Character string specifying the method. Default is "RMP".
#' @param target_sample_size_per_arm Numeric value for the target sample size per arm. Default is 93.
#'
#' @return This function doesn't return a value but saves the generated tables as HTML, PDF, and LaTeX files.
#'
#' @import dplyr
#' @import knitr
#' @import kableExtra
#' @import webshot2
#'
#' @export
table_bayesian_metrics_vs_parameters <- function(results_metrics_df,
                                                 case_study = "belimumab",
                                                 method = "RMP",
                                                 target_sample_size_per_arm = 93,
                                                 source_denominator_change_factor = 1,
                                                 target_to_source_std_ratio = 1) {
  results_df <- results_metrics_df %>%
    dplyr::filter(
      case_study == !!case_study,
      target_sample_size_per_arm == !!target_sample_size_per_arm,
      method == !!method,
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  results_df <- results_df %>%
    dplyr::mutate(
      design_prior_type = case_when(
        design_prior_type == "ui_design_prior" ~ "UI design prior",
        design_prior_type == "analysis_prior" ~ "Analysis prior",
        design_prior_type == "source_posterior" ~ "Source posterior",
        TRUE ~ design_prior_type
      )
    )

  parameters_df <- get_parameters(results_df[, "parameters"])

  methods_parameters <- methods_dict[[method]]

  # Loop through each parameter and create the data table
  for (i in 1:ncol(parameters_df)) {
    # Select the other parameters
    other_parameters <- unique(parameters_df[,-i])

    if (is.null(nrow(other_parameters)) || nrow(other_parameters) == 0){
      n_params_loop = 1
    } else {
      n_params_loop = nrow(other_parameters)
    }
    for (j in seq(n_params_loop)){
      if (is.null(nrow(other_parameters)) || nrow(other_parameters) == 0){
        other_params_label <- ""
        other_params_str <- ""
        parameters_subdf <- parameters_df
        results_subdf <- results_df
      } else {
        other_params_label <- make_labels_from_parameters(parameter = other_parameters[j,], method = method)
        other_params_label <- paste0(other_params_label, ", ")
        other_params_str <- convert_params_to_str(methods_dict[[method]], other_parameters[j,])

        # Filter the dataframe on the value of these other parameters
        matching_filter <- apply(parameters_df[,-i], 1, function(row) all(row == other_parameters[j,]))
        parameters_subdf <- parameters_df[matching_filter,]

        results_subdf <- results_df[matching_filter,]
      }

      if (length(unique(parameters_subdf[, i])) < 2) {
        next
      } else {
        parameter_values <- as.numeric(parameters_subdf[, i])
      }

      results_subdf$parameter_values <- parameter_values

      # Initialize data_table with sample size per arm
      data_table <- results_subdf %>%
        dplyr::select(parameter_values, design_prior_type) %>%
        dplyr::distinct() %>%
        dplyr::arrange(parameter_values)  #%>%
        #dplyr::mutate(parameter_values = as.double(parameter_values))

      # Add all bayesian metrics to the data_table
      for (metric_name in names(bayesian_metrics)) {
        metric <- bayesian_metrics[[metric_name]]
        data_table <- data_table %>%
          dplyr::left_join(
            results_subdf %>%
              dplyr::select(
                parameter_values,
                design_prior_type,
                !!rlang::sym(metric$name)
              ) %>%
              dplyr::distinct(),
            by = c("parameter_values", "design_prior_type")
          )
      }

      data_table <- data_table %>%
        #dplyr::group_by(parameter_values) %>%
        dplyr::rename(!!methods_parameters[[i]]$parameter_name := parameter_values)

      colnames(data_table) <- c(
        methods_parameters[[i]]$parameter_notation,
        "Design Prior",
        sapply(bayesian_metrics, function(x) {
          x$label
        })
      )

      directory <- file.path(tables_dir, case_study)
      if (!dir.exists(directory)) {
        dir.create(directory,
                   showWarnings = FALSE,
                   recursive = TRUE)
      }

      filename <- paste0(
        case_study,
        "_",
        method,
        "_bayesian_metrics_vs_parameters_target_sample_size_per_arm_",
        target_sample_size_per_arm
      )

      if (other_params_str != ""){
        filename <- paste0(filename, "_", other_params_str)
      }

      title <- sprintf(
        "%s, %s, %s, $N_T/2 = $ %s", str_to_title(case_study),
        methods_labels[[method]]$label,
        other_params_label,
        target_sample_size_per_arm
      )

      title <- format_title(title = title, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)
      filename <- format_filename(filename = filename, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)


      # if (!is.na(target_to_source_std_ratio)){
      #   filename <- paste0(
      #     case_study,
      #     "_",
      #     method,
      #     "_bayesian_metrics_vs_parameters_target_sample_size_per_arm_",
      #     target_sample_size_per_arm,
      #     "_target_to_source_std_ratio=",
      #     target_to_source_std_ratio,
      #     "_source_denominator_change_factor=",
      #     source_denominator_change_factor,
      #     other_params_str,
      #     "_table"
      #   )
      #
      #   title <- sprintf(
      #     "%s, $N_T/2 = $ %s, $\\sigma_T/\\sigma_S = $ %s, Source denominator change factor = %s", str_to_title(case_study),
      #     methods_labels[[method]]$label,
      #     other_params_label,
      #     target_sample_size_per_arm,
      #     target_to_source_std_ratio,
      #     source_denominator_change_factor
      #   )
      # } else {
      #   filename <- paste0(
      #     case_study,
      #     "_",
      #     method,
      #     "_bayesian_metrics_vs_parameters_target_sample_size_per_arm_",
      #     target_sample_size_per_arm,
      #     "_source_denominator_change_factor=",
      #     source_denominator_change_factor,
      #     other_params_str,
      #     "_table"
      #   )
      #
      #   title <- sprintf(
      #     "%s, $N_T/2 = $ %s, $\\sigma_T/\\sigma_S = $ %s, Source denominator change factor = %s", str_to_title(case_study),
      #     methods_labels[[method]]$label,
      #     other_params_label,
      #     target_sample_size_per_arm,
      #     source_denominator_change_factor
      #   )
      # }

      file_path <- file.path(directory, filename)

      export_table(data_table = data_table, ncollapses = 1, column_names = colnames(data_table), title = title, file_path = file_path, format = c("latex", "html", "pdf"))
    }
  }
}


#' Generate tables for metrics vs sample size
#'
#' This function creates tables comparing Bayesian metrics against different sample sizes for a given case study and method.
#'
#' @param results_metrics_df A data frame containing the results and metrics.
#' @param case_study Character string specifying the case study.
#' @param method Character string specifying the method.
#' @param parameters_combinations A data frame of parameter combinations to consider.
#'
#' @return This function doesn't return a value but saves the generated tables as HTML, PDF, and LaTeX files.
#'
#' @import dplyr
#' @import knitr
#' @import kableExtra
#' @import webshot2
#'
#' @export
table_bayesian_metrics_vs_sample_size <- function(results_metrics_df,
                                                  case_study,
                                                  method,
                                                  parameters_combinations,
                                                  source_denominator_change_factor = 1,
                                                  target_to_source_std_ratio = 1) {
  results_df <- results_metrics_df %>%
    dplyr::filter(
      case_study == !!case_study,
      method == !!method,
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  results_df <- results_df %>%
    dplyr::mutate(
      design_prior_type = case_when(
        design_prior_type == "ui_design_prior" ~ "UI design prior",
        design_prior_type == "analysis_prior" ~ "Analysis prior",
        design_prior_type == "source_posterior" ~ "Source posterior",
        TRUE ~ design_prior_type
      )
    )

  results_df <- cbind(results_df, get_parameters(results_df[, "parameters"]))

  results_df <- merge(results_df, parameters_combinations[, ])

  case_study_config <- yaml::read_yaml(paste0(case_studies_config_dir, case_study, ".yml"))

  # Initialize data_table with sample size per arm
  data_table <- results_df %>%
    dplyr::select(target_sample_size_per_arm, design_prior_type) %>%
    dplyr::distinct() %>%
    dplyr::arrange(target_sample_size_per_arm)

  # Add all bayesian metrics to the data_table
  for (metric_name in names(bayesian_metrics)) {
    metric <- bayesian_metrics[[metric_name]]
    data_table <- data_table %>%
      dplyr::left_join(
        results_df %>%
          dplyr::select(
            target_sample_size_per_arm,
            design_prior_type,
            !!rlang::sym(metric$name)
          ) %>%
          dplyr::distinct(),
        by = c("target_sample_size_per_arm", "design_prior_type")
      )
  }

  # Rename columns for display
  colnames(data_table) <- c("Sample Size per Arm",
                            "Design Prior",
                            sapply(bayesian_metrics, function(x) {
                              x$label
                            }))

  directory <- file.path(tables_dir, case_study)
  if (!dir.exists(directory)) {
    dir.create(directory, showWarnings = FALSE, recursive = TRUE)
  }


  filename <- paste0(
        case_study,
        "_",
        method,
        "_bayesian_metrics_vs_target_sample_size_per_arm_",
        convert_params_to_str(methods_dict[[method]], parameters_combinations)
      )


  param_label <- make_labels_from_parameters(parameters_combinations, method)

  if (param_label == "") {
    param_label <- paste0("")
  } else {
    param_label <- paste0(", ", param_label)
  }

  title <-  TeX(
    sprintf(
      "%s, %s, %s",
      str_to_title(case_study),
      methods_labels[[method]]$label,
      param_label
    )
  )

  title <- format_title(title = title, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)
  filename <- format_filename(filename = filename, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)

  # if (!is.na(target_to_source_std_ratio)){
  #   filename <- paste0(
  #     case_study,
  #     "_",
  #     method,
  #     "_bayesian_metrics_vs_target_sample_size_per_arm_",
  #     convert_params_to_str(methods_dict[[method]], parameters_combinations),
  #     "_target_to_source_std_ratio=",
  #     target_to_source_std_ratio,
  #     "_source_denominator_change_factor=",
  #     source_denominator_change_factor,
  #     "_table"
  #   )
  #
  #   title <-  TeX(
  #     sprintf(
  #       "%s, %s, %s, $\\sigma_T/\\sigma_S = $ %s, Source denominator change factor = %s",
  #       str_to_title(case_study),
  #       methods_labels[[method]]$label,
  #       param_label,
  #       target_to_source_std_ratio,
  #       source_denominator_change_factor
  #     )
  #   )
  # } else {
  #   filename <- paste0(
  #     case_study,
  #     "_",
  #     method,
  #     "_bayesian_metrics_vs_target_sample_size_per_arm_",
  #     convert_params_to_str(methods_dict[[method]], parameters_combinations),
  #     "_source_denominator_change_factor=",
  #     source_denominator_change_factor,
  #     "_table"
  #   )
  #   title <-  TeX(
  #     sprintf(
  #       "%s, %s, %s, Source denominator change factor = %s",
  #       str_to_title(case_study),
  #       methods_labels[[method]]$label,
  #       param_label,
  #       source_denominator_change_factor
  #     )
  #   )
  # }

  file_path <- file.path(directory, filename)

  export_table(data_table = data_table, ncollapses = 1, title = title, file_path = file_path, format = c("latex", "html", "pdf"))
}

#' Generate tables for methods operating characteristics
#'
#' This function creates tables for various Bayesian operating characteristics across different case studies and methods.
#'
#' @param results_metrics_df A data frame containing the results and metrics.
#' @param metrics A vector of metric names to include in the tables.
#'
#' @return This function doesn't return a value but calls other functions to generate and save tables.
#'
#' @import dplyr
#' @import yaml
#'
#' @export
table_bayesian_ocs <- function(results_metrics_df, metrics, source_denominator_change_factor = 1,
                               target_to_source_std_ratio = 1) {
  case_studies <- unique(results_metrics_df$case_study)
  methods <- unique(results_metrics_df$method)

  results_metrics_df <- results_metrics_df %>%
    dplyr::filter(
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )


  for (case_study in case_studies) {
    results_df <- results_metrics_df %>%
      dplyr::filter(case_study == !!case_study)

    for (method in methods) {
      if (sum(results_df$method == method) == 0) {
        next
      }

      filtered_results_df <- results_df %>%
        dplyr::filter(method == !!method)

      parameters_combinations <- unique(get_parameters(filtered_results_df[, "parameters"]))

      target_sample_sizes_per_arm <- unique(results_df$target_sample_size_per_arm[results_df$case_study == case_study])

      for (sample_size_per_arm in target_sample_sizes_per_arm) {
        table_bayesian_metrics_vs_parameters(
          results_metrics_df = filtered_results_df,
          case_study = case_study,
          method = method,
          target_sample_size_per_arm = sample_size_per_arm
        )
      }

      for (i in 1:nrow(parameters_combinations)) {
        table_bayesian_metrics_vs_sample_size(
          results_metrics_df = filtered_results_df,
          case_study = case_study,
          method = method,
          parameters_combinations = parameters_combinations[i, , drop = FALSE]
        )
      }
    }
  }
}
