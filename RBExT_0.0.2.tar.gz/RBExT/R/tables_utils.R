export_table = function(data_table, ncollapses, column_names = NULL, title, file_path, format = "html") {

  if (is.null(column_names)){
    column_names = colnames(data_table)
  }

  html_file <- paste0(file_path, ".html")
  if ("html" %in% format){
    data_kable <- data_table %>%
      knitr::kable(
        format = "html",
        col.names = column_names,
        row.names = FALSE,
        caption = title,
        escape = FALSE,
        digits = 3
      ) %>%
      kableExtra::collapse_rows(columns = 1:ncollapses, valign = "middle")

    # Add inline CSS to set CMU Serif font
    data_kable <- gsub(
      "<table",
      "<table style='font-family: \"CMU Serif\", serif; font-size: 12px;'",
      data_kable
    )

    # Add MathJax support for LaTeX rendering
    data_kable <- paste0(
      "<script type='text/javascript' async
              src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML'></script>",
      data_kable
    )

    kableExtra::save_kable(data_kable, html_file)
  }

  if ("latex" %in% format){
    data_kable <- data_table %>%
      knitr::kable(
        format = "latex",
        col.names = column_names,
        row.names = FALSE,
        caption = title,
        escape = FALSE,
        digits = 3
      ) %>%
      kableExtra::collapse_rows(columns = 1:ncollapses, valign = "middle")

    column_names <- gsub("%", "\\\\%", column_names)
    column_names <- lapply(column_names, function(x) paste0("\\textbf{", x, "}"))

    data_kable <- data_table %>%
      knitr::kable(
        format = "latex",
        booktabs = TRUE,
        longtable = TRUE,
        col.names = column_names,
        caption = title,
        escape = FALSE,
        digits = 3
      ) %>%
      kableExtra::collapse_rows(columns = 1:ncollapses, valign = "middle")

    # Write LaTeX code to file
    cat(data_kable, file = paste0(file_path, ".tex"))
  }

  if ("pdf" %in% format){
    pdf_file <- paste0(file_path, ".pdf")

    if (!"html" %in% format) {
      # If HTML is not already generated, create it
      data_kable <- data_table %>%
        knitr::kable(
          format = "html",
          col.names = column_names,
          row.names = FALSE,
          caption = title,
          escape = FALSE,
          digits = 3
        ) %>%
        kableExtra::collapse_rows(columns = 1:ncollapses, valign = "middle")

      data_kable <- gsub(
        "<table",
        "<table style='font-family: \"CMU Serif\", serif; font-size: 12px;'",
        data_kable
      )

      data_kable <- paste0(
        "<script type='text/javascript' async
                src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML'></script>",
        data_kable
      )

      kableExtra::save_kable(data_kable, html_file)
    }

    # Convert the HTML to PDF with MathJax rendering
    webshot2::webshot(url = html_file, file = pdf_file, delay = 2)
  }
}
