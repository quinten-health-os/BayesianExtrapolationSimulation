#' Function to plot metric vs parameters
#'
#' @description This function plots a metric against the parameters for a given method, case study, and sample size.
#'
#' @param results_metrics_df The data frame containing the results and metrics.
#' @param metric The metric to plot.
#' @param case_study The case study to plot the metric for.
#' @param method The method to plot the metric for.
#' @param target_sample_size_per_arm The target sample size per arm to plot the metric for.
#' @param theta_0 The baseline value for the metric.
#' @param add_baselines A logical value indicating whether to add baselines to the plot.
#'
#' @return None
#'
#' @export
bayesian_metric_vs_parameters <- function(results_metrics_df,
                                          metric,
                                          case_study = "belimumab",
                                          method = "RMP",
                                          target_sample_size_per_arm = 93,
                                          theta_0 = NULL,
                                          add_baselines = FALSE,
                                          source_denominator_change_factor = 1,
                                          target_to_source_std_ratio = 1) {
  # Filter results_metrics_df on the selected case study, target sample arm and method
  results_df <- results_metrics_df %>%
    dplyr::filter(
      case_study == !!case_study,
      target_sample_size_per_arm == !!target_sample_size_per_arm,
      method == !!method,
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  case_study_config <- yaml::read_yaml(paste0(case_studies_config_dir, case_study, ".yml"))

  # Filter on important drift value
  source_treatment_effect_estimate <- unique(results_df$source_treatment_effect_estimate)[1]
  mandatory_drift_values <- important_drift_values(source_treatment_effect_estimate, case_study_config)

  if ("drift" %in% colnames(results_df)) {
    # Find the closest values in df$target_treatment_effect to important_target_treatment_effects
    closest_values <- sapply(mandatory_drift_values, function(x) {
      results_df$drift[which.min(abs(results_df$drift - x))]
    })

    # Filter the dataframe to keep only the rows with the closest values
    results_df <- results_df %>%
      dplyr::filter(drift %in% closest_values) %>%
      dplyr::arrange(drift)

    if (length(unique(results_df$drift)) != 3) {
      stop("Only three main treatment effect values should be selected")
    }
  }

  if (nrow(results_df) == 0) {
    stop("Dataframe is empty")
  }

  results_df[results_df[, "design_prior_type"] == "analysis_prior", "label"] <- "Analysis prior"
  results_df[results_df[, "design_prior_type"] == "source_posterior", "label"] <- "Source posterior"
  results_df[results_df[, "design_prior_type"] == "ui_design_prior", "label"] <- "UI prior"

  results_df <- results_df %>%
    filter(!is.na(prepost_proba_TP) & !is.na(average_t1e) & !is.na(average_power) & !is.na(prior_proba_success) & !is.na(prior_proba_no_benefit) & !is.na(prepost_proba_FP) & !is.na(upper_bound_proba_FP))

  design_priors <- unlist(unique(results_df[, "label"]))


  parameters_df <- get_parameters(results_df[, "parameters"])

  methods_parameters <- methods_dict[[method]]

  if (metric %in% names(bayesian_metrics)) {
    selected_metric <- bayesian_metrics[[metric]]
  } else {
    stop("Metric is not supported")
  }

  if (is.null(selected_metric$name)) {
    stop("Metric name is NULL")
  }

  selected_metric_name <- rlang::sym(selected_metric$name)
  selected_label <- selected_metric$label

  labels_title <- "Design prior"

  color_map <- viridis::viridis(length(design_priors))


  for (i in 1:ncol(parameters_df)) {
    # Select the other parameters
    other_parameters <- unique(parameters_df[,-i])

    if (is.null(nrow(other_parameters)) || nrow(other_parameters) == 0){
      n_params_loop = 1
    } else {
      n_params_loop = nrow(other_parameters)
    }
    for (j in seq(n_params_loop)){
      if (is.null(nrow(other_parameters)) || nrow(other_parameters) == 0){
        other_params_label <- ""
        other_params_str <- ""
        parameters_subdf <- parameters_df
        results_subdf <- results_df
      } else {
        other_params_label <- make_labels_from_parameters(parameter = other_parameters[j,], method = method)
        other_params_label <- paste0(other_params_label, ", ")
        other_params_str <- convert_params_to_str(methods_dict[[method]], other_parameters[j,])

        # Filter the dataframe on the value of these other parameters
        matching_filter <- apply(parameters_df[,-i], 1, function(row) all(row == other_parameters[j,]))
        parameters_subdf <- parameters_df[matching_filter,]

        results_subdf <- results_df[matching_filter,]
      }

      if (length(unique(parameters_subdf[, i])) < 2) {
        next
      } else {
        parameter_values <- as.numeric(parameters_subdf[, i])
      }

      # Calculate the range of the x-axis
      x_range <- range(parameter_values)
      x_width <- diff(x_range)
      # Set a relative cap size (necessary, otherwise the cap size will depend on the x-axis width)
      cap_size <- x_width * relative_error_cap_width # Adjust relative_error_cap_width to control the relative cap size

      results_subdf$parameter_values <- parameter_values

      plot_title =
        sprintf(
          "%s, %s, %s $N_T/2 = $ %s",
          str_to_title(case_study),
          methods_labels[[method]]$label,
          other_params_label,
          target_sample_size_per_arm
        )

      plot_title <- format_title(title = plot_title, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)

      # Produce the plot
      plt <- ggplot2::ggplot(
        results_subdf,
        ggplot2::aes(
          x = parameter_values,
          y = !!selected_metric_name,
          group = as.factor(label),
          color = as.factor(label)
        )
      ) +
        geom_point() +
        # geom_point(position = position_dodge(width = cap_size / 2)) +
        scale_color_manual(values = color_map,
                           name = NULL,
                           labels = design_priors) +
        ggplot2::labs(
          title = plot_title,
          x = latex2exp::TeX(methods_parameters[[i]]$parameter_notation),
          y = selected_metric$label,
          color = "Design prior",
          group = "Design prior"
        ) +
        geom_line() +
        ggplot2::labs(color = labels_title)
      # scale_color_viridis_d()  + # Apply the viridis color map for discrete data

      # Add a y-line at theta = 0
      if (add_baselines) {
        plt <- plt + geom_hline(yintercept = theta_0, linetype = "dashed")
      }


      # Save plot
      directory <- paste0(figures_dir, case_study)
      if (!dir.exists(directory)) {
        dir.create(directory,
                   showWarnings = FALSE,
                   recursive = TRUE)
      }

      figure_name <- paste0(
        case_study,
        "_",
        method,
        "_",
        selected_metric_name,
        "_vs_parameters_target_sample_size_per_arm_",
        target_sample_size_per_arm
      )

      if (other_params_str != ""){
        figure_name <- paste0(figure_name, "_", other_params_str)
      }

      figure_name <- format_filename(filename = figure_name, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)


      plot.size <- set_size(textwidth)
      fig_width_in <- plot.size[1]
      fig_height_in <- plot.size[2]

      file_path <- file.path(directory, figure_name)

      export_plots(plt, file_path, fig_width_in, fig_height_in, type = "pdf")
      export_plots(plt, file_path, fig_width_in, fig_height_in, type = "png")
    }
  }
}

#' Function to plot metric vs sample size
#'
#' @description This function plots a metric against the sample size for a given method, case study, and parameters combinations.
#'
#' @param metric The metric to plot.
#' @param results_metrics_df The data frame containing the results and metrics.
#' @param case_study The case study to plot the metric for.
#' @param method The method to plot the metric for.
#' @param parameters_combinations The parameter combinations to filter the data on.
#' @param theta_0 The baseline value for the metric.
#' @param add_baselines A logical value indicating whether to add baselines to the plot.
#' @param target_to_source_std_ratio Ratio between the sampling standard deviation in the source study and in the target study.
#'
#' @return None
#'
#' @export
bayesian_metric_vs_sample_size <- function(metric,
                                           input_df,
                                           case_study,
                                           method,
                                           parameters_combinations,
                                           theta_0 = 0,
                                           add_baselines = FALSE,
                                           target_to_source_std_ratio = 1,
                                           source_denominator_change_factor = 1) {
  # Filter on the selected case study, method, etc
  results_df <- input_df %>%
    dplyr::filter(
      case_study == !!case_study,
      method == !!method,
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  # Format the parameters (from the json string)
  results_df <- cbind(results_df, get_parameters(results_df[, "parameters"]))

  # Filter rows that match parameters_combinations
  results_df <- merge(results_df, parameters_combinations[, ])

  case_study_config <- yaml::read_yaml(paste0(case_studies_config_dir, case_study, ".yml"))

  # Filter on important drift value
  source_treatment_effect_estimate <- unique(results_df$source_treatment_effect_estimate)[1]
  mandatory_drift_values <- important_drift_values(source_treatment_effect_estimate, case_study_config)

  if ("drift" %in% colnames(results_df)) {
    # Find the closest values in df$target_treatment_effect to important_target_treatment_effects
    closest_values <- sapply(mandatory_drift_values, function(x) {
      results_df$drift[which.min(abs(results_df$drift - x))]
    })

    # Filter the dataframe to keep only the rows with the closest values
    results_df <- results_df %>%
      dplyr::filter(drift %in% closest_values) %>%
      dplyr::arrange(drift)

    if (length(unique(results_df$drift)) != 3) {
      stop("Only three main treatment effect values should be selected")
    }
  }

  # Plot setup
  color_map <- viridis::viridis(length(mandatory_drift_values))

  # Extract the metric of interest
  if (metric %in% names(frequentist_metrics)) {
    selected_metric <- frequentist_metrics[[metric]]
  } else if (metric %in% names(inference_metrics)) {
    selected_metric <- inference_metrics[[metric]]
  } else if (metric %in% names(bayesian_metrics)) {
    selected_metric <- bayesian_metrics[[metric]]
  } else {
    stop("Metric is not supported")
  }

  if (is.null(selected_metric$name)) {
    stop("Metric name is NULL")
  }
  selected_metric_name <- rlang::sym(selected_metric$name)
  selected_label <- selected_metric$label

  # Calculate the range of the x-axis
  x_range <- range(results_df$target_sample_size_per_arm)
  x_width <- diff(x_range)
  # Set a relative cap size (necessary, otherwise the cap size will depend on the x-axis width)
  cap_size <- x_width * relative_error_cap_width # Adjust relative_error_cap_width to control the relative cap size

  labels_title <- "Design prior"

  results_df[results_df[, "design_prior_type"] == "analysis_prior", "label"] <- "Analysis prior"
  results_df[results_df[, "design_prior_type"] == "source_posterior", "label"] <- "Source posterior"
  results_df[results_df[, "design_prior_type"] == "ui_design_prior", "label"] <- "UI prior"

  results_df <- results_df %>%
    filter(!is.na(prepost_proba_TP) & !is.na(average_t1e) & !is.na(average_power) & !is.na(prior_proba_success) & !is.na(prior_proba_no_benefit) & !is.na(prepost_proba_FP) & !is.na(upper_bound_proba_FP))

  design_priors_names <- unique(results_df[, "label"])

  color_map <- viridis::viridis(length(design_priors_names))


  if (nrow(results_df) == 0) {
    stop("Dataframe is empty")
  }

  param_label <- make_labels_from_parameters(parameters_combinations, method)

  if (param_label == "") {
    param_label <- paste0("")
  } else {
    param_label <- paste0(", ", param_label)
  }


  figure_name <- paste0(
    case_study,
    "_",
    method,
    "_",
    selected_metric_name,
    "_vs_target_sample_size_per_arm_",
    convert_params_to_str(methods_dict[[method]], parameters_combinations)
  )

  plot_title <-
    sprintf(
      "%s, %s %s",
      str_to_title(case_study),
      methods_labels[[method]]$label,
      param_label
    )

  plot_title <- format_title(title = plot_title, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)
  figure_name <- format_filename(filename = figure_name, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)


  # Produce the plot
  plt <- ggplot2::ggplot(
    results_df,
    ggplot2::aes(
      x = target_sample_size_per_arm,
      y = !!selected_metric_name,
      group = as.factor(label),
      color = as.factor(label)
    )
  ) +
    geom_point() +
    # geom_point(position = position_dodge(width = cap_size / 2)) +
    geom_line() +
    scale_x_continuous(name = "Target study sample size per arm") +
    scale_y_continuous(name = selected_label) +
    ggplot2::labs(color = labels_title) +
    scale_color_manual(values = color_map,
                       name = NULL,
                       labels = design_priors_names)

  plt <- plt +
    ggplot2::labs(title = plot_title)

  # Add a y-line at theta = 0
  if (add_baselines) {
    plt <- plt + geom_hline(yintercept = theta_0, linetype = "dashed")
  }

  # Save plot
  directory <- paste0(figures_dir, case_study)
  if (!dir.exists(directory)) {
    dir.create(directory, showWarnings = FALSE, recursive = TRUE)
  }

  plot.size <- set_size(textwidth)
  fig_width_in <- plot.size[1]
  fig_height_in <- plot.size[2]

  file_path <- file.path(directory, figure_name)
  export_plots(plt, file_path, fig_width_in, fig_height_in, type = "pdf")
  export_plots(plt, file_path, fig_width_in, fig_height_in, type = "png")

}



#' Plot methods operating characteristics
#'
#' @description This function generates plots for the operating characteristics of different methods.
#'
#' @param results_metrics_df The data frame containing the results and metrics.
#' @param metrics A list of metrics to be plotted.
#'
#' @return None
#'
#' @examples NA
bayesian_ocs_plots <- function(results_metrics_df, metrics, source_denominator_change_factor= 1, target_to_source_std_ratio = 1) {
  # Get the list of case studies
  case_studies <- unique(results_metrics_df$case_study)

  # Get the list of methods
  methods <- unique(results_metrics_df$method)

  for (case_study in case_studies) {
    results_df <- results_metrics_df %>%
      dplyr::filter(
        case_study == !!case_study,
        source_denominator_change_factor == !!source_denominator_change_factor  |
          is.na(source_denominator_change_factor),
        target_to_source_std_ratio == !!target_to_source_std_ratio |
          is.na(target_to_source_std_ratio)
      )


    conf <- yaml::yaml.load_file(system.file(paste0(
      "conf/case_studies/", case_study, ".yml"
    )))
    theta_0 <- conf$theta_0

    for (method in methods) {
      if (sum(results_df$method == method) == 0) {
        next
      }
      # Get the different parameters combinations studies for this method

      filtered_results_df <- results_metrics_df %>%
        dplyr::filter(method == !!method, )

      parameters_combinations <- unique(get_parameters(filtered_results_df[, "parameters"]))

      if (method %in% c("separate", "pooling")) {
        add_baselines <- FALSE
      } else {
        add_baselines <- TRUE
      }

      target_sample_sizes_per_arm <- unique(results_df$target_sample_size_per_arm[results_df$case_study == case_study])


      for (metric in names(metrics)) {
        for (sample_size_per_arm in target_sample_sizes_per_arm) {
          bayesian_metric_vs_parameters(
            results_metrics_df = filtered_results_df,
            case_study = case_study,
            method = method,
            target_sample_size_per_arm = sample_size_per_arm,
            metric = metric,
            theta_0 = theta_0
          )
        }

        for (i in 1:nrow(parameters_combinations)) {
          bayesian_metric_vs_sample_size(
            metric = metric,
            input_df = filtered_results_df,
            case_study = case_study,
            method = method,
            parameters_combinations = parameters_combinations[i, , drop = FALSE],
            theta_0 = theta_0,
            add_baselines = add_baselines
          )
        }
      }
    }
  }
}
