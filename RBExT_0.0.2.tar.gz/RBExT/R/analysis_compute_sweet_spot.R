#' Determine Sweet Spot Bounds and Width
#'
#' @description This function calculates the bounds and width of the "sweet spot" where a given `y_values` vector
#' crosses a specified `reference_value`. It uses linear interpolation for precise crossing points.
#'
#' @param x_values A numeric vector of x values.
#' @param y_values A numeric vector of y values.
#' @param reference_value A numeric reference value to determine the crossing points.
#'
#' @return A list containing:
#' \itemize{
#'     \item sweet_spot_bounds A numeric vector of length 2 with the lower and upper bounds of the sweet spot.
#'     \item sweet_spot_widthA numeric value indicating the width of the sweet spot.
#'   }
sweet_spot_determination <- function(x_values, y_values, reference_value = 0, larger_is_better, return_NA_at_boundaries = FALSE) {
  if (length(x_values) == 0 || length(y_values) == 0) {
    warnings("Input vectors must have non-zero length.")
    futile.logger::flog.warn("Input vectors must have non-zero length.")
    sweet_spot_bounds <- c(NA, NA)
    sweet_spot_width <- NA
    return(
      list(
        sweet_spot_bounds = sweet_spot_bounds,
        sweet_spot_width = sweet_spot_width
      )
    )
  }

  xrange <- range(x_values)

  # Convert the y_values and reference_value so that larger is better
  if (!larger_is_better){
    y_values <- -y_values
    reference_value <- -reference_value
  }

  # Define a custom sign function that treats zero as positive
  sign_y <- sign(y_values - reference_value)
  sign_y[sign_y == 0] <- 1
  # Find where the function crosses the reference value
  crossings <- which(diff(sign_y) != 0)

  if (length(crossings) == 0) {
      if (return_NA_at_boundaries){
        sweet_spot_bounds = c(NA, NA)
        sweet_spot_width <- NA
      } else {
        sweet_spot_bounds = xrange
        sweet_spot_width <- sweet_spot_bounds[2] - sweet_spot_bounds[1]
      }
    return(
      list(
        sweet_spot_bounds = sweet_spot_bounds,
        sweet_spot_width = sweet_spot_width
      )
    )
  }

  # Use linear interpolation to find more precise x values at crossings
  precise_crossings <- numeric(length(crossings))
  for (i in seq_along(1:length(crossings))) {
    precise_crossings[i] <- approx(x = y_values[c(crossings[i], crossings[i] + 1)], y = x_values[c(crossings[i], crossings[i] + 1)], xout = reference_value)$y
  }

  if (length(precise_crossings) > 2) {
    stop("More than one sweet spot.")
  } else if (length(precise_crossings) == 1) {
    if (y_values[crossings] < y_values[crossings + 1]) {
      if (return_NA_at_boundaries){
        sweet_spot_bounds <- c(precise_crossings, NA)
        sweet_spot_width <- NA
      } else {
        sweet_spot_bounds <- c(precise_crossings, xrange[2])
        sweet_spot_width <- sweet_spot_bounds[2] - sweet_spot_bounds[1]
      }
    } else {
      if (return_NA_at_boundaries){
        sweet_spot_bounds <- c(NA, precise_crossings)
        sweet_spot_width <- NA
      } else {
        sweet_spot_bounds <- c(xrange[1], precise_crossings)
        sweet_spot_width <- sweet_spot_bounds[2] - sweet_spot_bounds[1]
      }
    }
  } else if (length(precise_crossings) == 0) {
    if (return_NA_at_boundaries){
      sweet_spot_bounds = c(NA, NA)
      sweet_spot_width <- NA
    } else {
      sweet_spot_bounds = xrange
      sweet_spot_width <- sweet_spot_bounds[2] - sweet_spot_bounds[1]
    }
  } else if (length(precise_crossings) == 2) {
      sweet_spot_bounds = xrange
      sweet_spot_width <- sweet_spot_bounds[2] - sweet_spot_bounds[1]
  }

  return(list(sweet_spot_bounds = sweet_spot_bounds, sweet_spot_width = sweet_spot_width))
}

compare_metrics <- function(merged_df, metric_1, metric_2, based_on_CI = based_on_CI, suffix = ""){
  if (based_on_CI){
    if (metric_1$larger_is_better){
     difference <- merged_df[[paste0("conf_int_", metric_1$name, "_lower")]] - merged_df[[paste0("conf_int_", metric_2$name, "_upper", suffix)]]
    } else {
      difference <- merged_df[[paste0("conf_int_", metric_1$name, "_upper")]] - merged_df[[paste0("conf_int_", metric_2$name, "_lower", suffix)]]
    }
  } else {
    difference <- merged_df[[metric_1$name]] - merged_df[[paste0(metric_2$name, suffix)]]
  }

  return(difference)
}


#' Calculate Sweet Spots for Multiple Metrics
#'
#' @description This function calculates the sweet spots for various metrics over multiple case studies and methods.
#' It determines where the metric differences between two methods cross a reference value.
#'
#' @param results_freq_df A dataframe containing the results frequency data with columns
#' "case_study", "method", "source_denominator_change_factor", "control_drift", and "target_sample_size_per_arm".
#' @param metrics A list of metrics to evaluate. Each metric should have a `name` attribute.
#'
#' @return A dataframe containing the sweet spots for each metric, case study, method, and combination
#' of parameters.
#'
#' @examples
#' \dontrun{
#' results <- sweet_spot(results_freq_df, metrics)
#' }
sweet_spot <- function(results_freq_df, metrics, based_on_CI = TRUE) {
  scenario_columns <- c("target_sample_size_per_arm", "control_drift", "source_denominator", "source_denominator_change_factor",
                        "case_study", "parallelization", "sampling_approximation", "source_treatment_effect_estimate",
                        "target_to_source_std_ratio", "theta_0", "null_space",
                        "summary_measure_likelihood", "source_standard_error", "source_sample_size_control",
                        "source_sample_size_treatment", "equivalent_source_sample_size_per_arm", "endpoint",
                        "source_control_rate", "source_treatment_rate")

  results_columns <- c("success_proba", "mcse_success_proba", "conf_int_success_proba_lower",
                       "conf_int_success_proba_upper", "coverage", "conf_int_coverage_lower",
                       "conf_int_coverage_upper", "mse", "conf_int_mse_lower", "conf_int_mse_upper",
                       "bias", "conf_int_bias_lower", "conf_int_bias_upper", "posterior_mean",
                       "conf_int_posterior_mean_lower", "conf_int_posterior_mean_upper", "posterior_median",
                       "conf_int_posterior_median_lower", "conf_int_posterior_median_upper", "precision",
                       "conf_int_precision_lower", "conf_int_precision_upper", "credible_interval_lower",
                       "credible_interval_upper", "posterior_parameters", "ess_moment",
                       "conf_int_ess_moment_lower", "conf_int_ess_moment_upper", "ess_precision",
                       "conf_int_ess_precision_lower", "conf_int_ess_precision_upper", "ess_elir",
                       "conf_int_ess_elir_lower", "conf_int_ess_elir_upper", "rhat", "conf_int_rhat_lower",
                       "conf_int_rhat_upper", "mcmc_ess", "conf_int_mcmc_ess_lower", "conf_int_mcmc_ess_upper",
                       "n_divergences", "conf_int_n_divergences_lower", "conf_int_n_divergences_upper",
                       "warning", "tie", "mcse_tie", "conf_int_tie_lower", "conf_int_tie_upper",
                       "frequentist_power_at_equivalent_tie", "frequentist_power_at_equivalent_tie_lower",
                       "frequentist_power_at_equivalent_tie_upper", "frequentist_test",
                       "nominal_frequentist_power_separate", "nominal_frequentist_power_pooling")

  # Initialize an empty dataframe to store the results
  final_df <- data.frame(
    metric = character(),
    method = character(),
    parameters = character(),
    target_sample_size_per_arm = numeric(),
    control_drift = numeric(),
    source_denominator = numeric(),
    source_denominator_change_factor = numeric(),
    case_study = character(),
    parallelization = logical(),
    sampling_approximation = logical(),
    source_treatment_effect_estimate = numeric(),
    target_to_source_std_ratio = numeric(),
    theta_0 = numeric(),
    null_space = character(),
    summary_measure_likelihood = character(),
    source_standard_error = numeric(),
    source_sample_size_control = numeric(),
    source_sample_size_treatment = numeric(),
    equivalent_source_sample_size_per_arm = numeric(),
    endpoint = character(),
    source_control_rate = numeric(),
    source_treatment_rate = numeric(),
    sweet_spot_lower = numeric(),
    sweet_spot_upper = numeric(),
    sweet_spot_width = numeric(),
    drift_range_upper = numeric(),
    drift_range_lower = numeric(),
    stringsAsFactors = FALSE
  )

  # Loop through each unique combination to calculate sweet spots
  for (case_study in unique(results_freq_df$case_study)) {
      results_freq_df1 = results_freq_df[results_freq_df$case_study == case_study, ]
      for (target_sample_size_per_arm in unique(results_freq_df1$target_sample_size_per_arm)) {
        results_freq_df2 = results_freq_df1[results_freq_df1$target_sample_size_per_arm == target_sample_size_per_arm, ]
        for (source_denominator_change_factor in unique(results_freq_df2$source_denominator_change_factor)) {
          results_freq_df3 = results_freq_df2[results_freq_df2$source_denominator_change_factor == source_denominator_change_factor, ]
          for (target_to_source_std_ratio in unique(results_freq_df3$target_to_source_std_ratio)){
            results_freq_df4 <- results_freq_df3 %>%
              dplyr::filter(
                target_to_source_std_ratio == !!target_to_source_std_ratio |
                  is.na(target_to_source_std_ratio)
              )

            df <- results_freq_df4[results_freq_df4$control_drift == 0, ]

            separate_df <- df[df$method == "separate", ]

            if (nrow(separate_df) == 0) {
              warning(
                "A separate analysis but be performed for comparison and sweet spot computation."
              )
              futile.logger::flog.warn("A separate analysis but be performed for comparison and sweet spot computation.")
            }

            if (nrow(df) > 0) {
              # Merge the dataframes on specified columns
              merged_df <- merge(
                df,
                separate_df,
                by = c("drift", "target_treatment_effect", scenario_columns),
                suffixes = c("", "_separate")
              )

              # Sort the dataframe by drift in ascending order
              merged_df <- merged_df %>%
                dplyr::arrange(drift)

              for (metric in metrics) {
                # Depending on whether the sweet spot is determined based on the mean or on the bounds of the CI, compute the difference based on which it will be computed.

                merged_df$metric_diff <- compare_metrics(merged_df, metric, metric, based_on_CI = based_on_CI, suffix = "_separate")

                # Determine the sweet spot location and width
                for (method in unique(merged_df$method)){
                  parameters_combinations <- unique(merged_df[merged_df$method == method,]$parameters)
                  for (parameters in parameters_combinations){
                    method_df <- merged_df[merged_df$parameters == parameters & merged_df$method == method,]

                    sweet_spot <- sweet_spot_determination(method_df$drift,
                                                           method_df$metric_diff,
                                                           larger_is_better = metric$larger_is_better)

                    if (nrow(method_df) == 0){
                      stop("Dataframe is empty.")
                    }

                    drift_range <- method_df$drift

                    df_to_add <- cbind(unique(method_df[, c("method", "parameters", scenario_columns)]), data.frame(
                      sweet_spot_lower = sweet_spot$sweet_spot_bounds[1],
                      sweet_spot_upper = sweet_spot$sweet_spot_bounds[2],
                      sweet_spot_width = sweet_spot$sweet_spot_width,
                      drift_range_upper = drift_range[2],
                      drift_range_lower = drift_range[1]
                    ))

                    df_to_add$metric <- metric$name

                    # Append the results to final_df
                    final_df <- rbind(
                      final_df,
                        df_to_add
                      )

                    if (metric$name == "success_proba") {
                      method_df$metric_diff <- method_df[["success_proba"]] - analysis_config$nominal_tie

                      # Determine the range of drift values for which the success proba is smaller than the nominal TIE
                      sweet_spot <- sweet_spot_determination(method_df$drift,
                                                             method_df$metric_diff,
                                                             larger_is_better = FALSE)

                      df_to_add <- cbind(unique(method_df[, c("method", "parameters", scenario_columns)]), data.frame(
                        sweet_spot_lower = sweet_spot$sweet_spot_bounds[1],
                        sweet_spot_upper = sweet_spot$sweet_spot_bounds[2],
                        sweet_spot_width = sweet_spot$sweet_spot_width,
                        drift_range_upper = drift_range[2],
                        drift_range_lower = drift_range[1]
                      )
                      )

                      df_to_add$metric <- "TIE_smaller_than_nominal"

                      final_df <- rbind(
                        final_df,
                        df_to_add
                      )

                      merged_df$metric_diff <- compare_metrics(method_df, metric, metric, based_on_CI = based_on_CI, suffix = "_separate")

                      # Determine the range of drift values for which the success proba is higher than the nominal power (the power of a frequentist analysis at nominal TIE)
                      sweet_spot <- sweet_spot_determination(method_df$drift,
                                                             method_df$metric_diff,
                                                             larger_is_better =  TRUE)


                      df_to_add <- cbind(unique(method_df[, c("method", "parameters", scenario_columns)]), data.frame(
                        sweet_spot_lower = sweet_spot$sweet_spot_bounds[1],
                        sweet_spot_upper = sweet_spot$sweet_spot_bounds[2],
                        sweet_spot_width = sweet_spot$sweet_spot_width,
                        drift_range_upper = drift_range[2],
                        drift_range_lower = drift_range[1]
                      )
                      )

                      df_to_add$metric <- "power_larger_than_nominal"

                      final_df <- rbind(
                        final_df,
                        df_to_add
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
  }

  return(final_df)
}
