#' Generate a table of posterior parameters vs drift
#'
#' This function creates tables comparing posterior parameters to drift for a given method, case study, and sample size.
#'
#' @param results_metrics_df A data frame containing the results metrics.
#' @param method The method to filter the results by.
#' @param case_study The case study to filter the results by.
#' @param target_sample_size_per_arm The target sample size per arm to filter the results by.
#' @param control_drift A logical value indicating whether to control for drift.
#' @param xvars A list containing the x-variable configurations.
#'
#' @return This function does not return a value. It creates and saves tables in HTML, PDF, and LaTeX formats.
#'
#' @import dplyr
#' @import knitr
#' @import kableExtra
#' @import webshot2
#'
#' @export
table_posterior_parameters_vs_drift <- function(results_metrics_df,
                                                method,
                                                case_study,
                                                target_sample_size_per_arm,
                                                control_drift,
                                                xvars,
                                                source_denominator_change_factor,
                                                target_to_source_std_ratio) {
  # Filter the data frame based on method, case_study, and target_sample_size_per_arm
  results_metrics_df <- results_metrics_df %>%
    dplyr::filter(
      method == !!method,
      case_study == !!case_study,
      target_sample_size_per_arm == !!target_sample_size_per_arm,
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  if (control_drift) {
    xvar <- xvars[["control_drift"]]
    xvar$name <- "control_drift"
    # Remove non-zero treatment drift
    results_metrics_df <- results_metrics_df %>%
      dplyr::filter(treatment_drift == 0)
  } else {
    xvar <- xvars[["drift"]]
    results_metrics_df <- results_metrics_df %>%
      dplyr::filter(control_drift == 0)
  }

  source_treatment_effect_estimate <- unique(results_metrics_df$source_treatment_effect_estimate)[1]

  case_study_config <- yaml::read_yaml(paste0(case_studies_config_dir, case_study, ".yml"))

  mandatory_drift_values <- important_drift_values(source_treatment_effect_estimate, case_study_config)

  posterior_parameters_df <- get_parameters(results_metrics_df[, "posterior_parameters"])

  prior_parameters_df <- get_parameters(results_metrics_df[, "parameters"])

  for (key in names(methods_dict[[method]])) {
    if (!key %in% colnames(posterior_parameters_df)) {
      next
    }

    important_parameters_values <- methods_dict[[method]][[key]][["important_values"]]
    # Table setup
    table_data <- list()
    for (i in seq_along(important_parameters_values)) {
      prior_param <- important_parameters_values[[i]]
      filter_df <- prior_parameters_df[key] == prior_param

      results_metrics_subdf <- results_metrics_df[filter_df,]
      browser()

      drift <- unlist(results_metrics_subdf[, xvar[["name"]]])
      posterior_param <- unlist(posterior_parameters_df[filter_df, key])

      posterior_param_conf_int_lower <- unlist(posterior_parameters_df[filter_df, paste0("conf_int_lower_", key)])
      posterior_param_conf_int_upper <- unlist(posterior_parameters_df[filter_df, paste0("conf_int_upper_", key)])

      table_data[[i]] <- data.frame(
        drift = drift,
        prior_param = prior_param,
        posterior_param = posterior_param,
        posterior_param_conf_int_lower= posterior_param_conf_int_lower,
        posterior_param_conf_int_upper = posterior_param_conf_int_upper
      )
    }

    # Combine all table data
    table_data_df <- dplyr::bind_rows(table_data)

    data_table <- table_data_df %>%
      dplyr::mutate(
        posterior_param = format_num(posterior_param),
        error_low = format_num(posterior_param_conf_int_lower),
        error_upper = format_num(posterior_param_conf_int_upper),
        CI = paste0("[", error_low, ", ", error_upper, "]")
      ) %>%
      dplyr::select(drift, prior_param, posterior_param, CI) %>%
      dplyr::arrange(drift)


    prior_parameter_colname <-sprintf("%s %s", "Prior", methods_dict[[method]][[key]]$parameter_notation)
    posterior_parameter_colname <-sprintf("%s %s", "Posterior", methods_dict[[method]][[key]]$parameter_notation)

    data_table <- data_table %>%
      dplyr::rename(
        "Drift" = drift,
        !!prior_parameter_colname := prior_param,
        "Posterior Parameter" = posterior_param,
        "Confidence Interval" = CI
      )

    # Merge Mean and CI columns
    data_table <- data_table %>%
      unite(!!posterior_parameter_colname, 'Posterior Parameter', 'Confidence Interval', sep = " ")


    directory <- file.path(tables_dir, case_study)
    if (!dir.exists(directory)) {
      dir.create(directory,
                 showWarnings = FALSE,
                 recursive = TRUE)
    }

    filename <- paste0(
      case_study,
      "_",
      method,
      "_posterior_",
      methods_dict[[method]][[key]]$parameter_label,
      "_vs_",
      xvar$name,
      "_sample_size_",
      target_sample_size_per_arm,
      "_",
      convert_params_to_str(
        method = methods_dict[[method]],
        parameters = unique(prior_parameters_df[, !names(prior_parameters_df) %in% key])
      )
    )


    filename <- format_filename(filename = filename, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)

    file_path <- file.path(directory, filename)

    title <-TeX(
      sprintf(
        "%s, %s, $N_T/2 =$ %s",
        str_to_title(case_study),
        method,
        target_sample_size_per_arm
      )
    )
    title <- format_title(title = title, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)

    export_table(data_table = data_table, ncollapses = 1, title = title, file_path = file_path, format = c("latex", "html", "pdf"))

    browser()
  }
}


#' Generate a table of posterior vs prior parameters
#'
#' This function creates tables comparing posterior parameters to prior parameters for a given method, case study, and sample size.
#'
#' @param results_metrics_df A data frame containing the results metrics.
#' @param method The method to filter the results by.
#' @param case_study The case study to filter the results by.
#' @param target_sample_size_per_arm The target sample size per arm to filter the results by.
#' @param metrics A list or vector of metrics to include in the analysis.
#'
#' @return This function does not return a value. It creates and saves tables in HTML, PDF, and LaTeX formats.
#'
#' @import dplyr
#' @import knitr
#' @import kableExtra
#' @import webshot2
#' @import yaml
#'
#' @export
table_posterior_vs_prior_parameters <- function(results_metrics_df,
                                                method,
                                                case_study,
                                                target_sample_size_per_arm,
                                                metrics,
                                                source_denominator_change_factor = 1,
                                                target_to_source_std_ratio = 1) {
  results_metrics_df <- results_metrics_df %>%
    dplyr::filter(
      method == !!method,
      case_study == !!case_study,
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_sample_size_per_arm == !!target_sample_size_per_arm,
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  if (nrow(results_metrics_df) == 0) {
    futile.logger::flog.warn("Dataframe is empty.")
    warnings("Dataframe is empty.")
    return()
  }

  source_treatment_effect_estimate <- unique(results_metrics_df$source_treatment_effect_estimate)[1]

  case_study_config <- yaml::read_yaml(paste0(case_studies_config_dir, case_study, ".yml"))

  mandatory_drift_values <- important_drift_values(source_treatment_effect_estimate, case_study_config)

  treatment_effects_names <- c("No effect",
                               "Partially consistent effect",
                               "Consistent effect")

  posterior_parameters_df <- get_parameters(results_metrics_df[, "posterior_parameters"])
  prior_parameters_df <- get_parameters(results_metrics_df[, "parameters"])

  # Loop over the prior parameters
  k <- 0
  for (key in names(methods_dict[[method]])) {
    k <- k+1
    # Check if the parameter is updated
    if (!key %in% colnames(posterior_parameters_df)) {
      next
    }

    if (length(methods_dict[[method]][[key]][['range']]) < 2){
      next
    }

    # Select the other parameters
    other_parameters <- unique(prior_parameters_df[,-k])

    if (is.null(nrow(other_parameters)) || nrow(other_parameters) == 0){
      n_params_loop = 1
    } else {
      n_params_loop = nrow(other_parameters)
    }

    # Loop over other prior parameters values
    for (j in seq(n_params_loop)){
      if (is.null(nrow(other_parameters)) || nrow(other_parameters) == 0){
        other_params_label <- ""
        other_params_str <- ""
        prior_parameters_subdf <- prior_parameters_df
        posterior_parameters_subdf <- posterior_parameters_df
        results_metrics_subdf <- results_metrics_df
      } else {
        other_params_label <- make_labels_from_parameters(parameter = other_parameters[j,], method = method)
        other_params_label <- paste0(other_params_label, ", ")
        other_params_str <- convert_params_to_str(methods_dict[[method]], other_parameters[j,])

        # Filter the dataframe on the value of these other parameters
        matching_filter <- apply(prior_parameters_df[,-k], 1, function(row) all(row == other_parameters[j,]))
        prior_parameters_subdf <- prior_parameters_df[matching_filter,]

        posterior_parameters_subdf <- posterior_parameters_df[matching_filter,]

        results_metrics_subdf <- results_metrics_df[matching_filter,]
      }


      # Loop over the posterior parameters
      posterior_colnames <- colnames(posterior_parameters_subdf)
      posterior_keys <- posterior_colnames[!grepl("^conf_int", posterior_colnames)]

      for (posterior_key in posterior_keys){

        # Combine all necessary data based on the drift values into a single data frame
        combined_data <- do.call(rbind, lapply(mandatory_drift_values, function(drift) {
          filter_df <- abs(results_metrics_subdf$drift - drift) < .Machine$double.eps ^ 0.5
          posterior_parameters <- posterior_parameters_subdf[filter_df, ]
          prior_parameters <- prior_parameters_subdf[filter_df, ]
          filtered_results_metrics_df <- results_metrics_df[filter_df, ]

          parameters_labels <- unname(sapply(1:nrow(filtered_results_metrics_df), function(i) {
            process_method_parameters_label(filtered_results_metrics_df[i, ],
                                            methods_labels,
                                            method_name = FALSE)
          }))
          parameters_labels <- setNames(object = parameters_labels, nm = filtered_results_metrics_df$parameters)

          x <- as.numeric(prior_parameters[[key]])
          y <- as.numeric(posterior_parameters[[posterior_key]])
          conf_int_lower <- unlist(posterior_parameters[[paste0("conf_int_lower_", posterior_key)]])
          conf_int_upper <- unlist(posterior_parameters[[paste0("conf_int_upper_", posterior_key)]])

          if (is.null(x)) {
            stop("x is null")
          }

          data.frame(
            x = x,
            y = y,
            conf_int_lower = conf_int_lower,
            conf_int_upper = conf_int_upper,
            drift = drift
          )
        }))

        title <- TeX(
          sprintf(
            "%s, %s, %s $N_T/2 = $ %s",
            str_to_title(case_study),
            methods_labels[[method]]$label,
            other_params_label,
            target_sample_size_per_arm
          )
        )

        title <- format_title(title = title, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)


        data_table <- table_data_df %>%
          dplyr::mutate(
            means = format_num(y),
            error_low = format_num(ymin),
            error_upper = format_num(ymax),
            CI = paste0("[", error_low, ", ", error_upper, "]")
          ) %>%
          dplyr::select(x, means, CI) %>%
          dplyr::arrange(x)

        browser()

        prior_parameter_colname <-sprintf("%s %s", "Prior", methods_dict[[method]][[key]]$parameter_notation)

        data_table <- data_table %>%
          #dplyr::group_by(x) %>%
          dplyr::rename(
            prior_parameter_colname = x, # methods_dict[[method]][[key]]$parameter_notation
            "Posterior Parameter" = means,
            "Confidence Interval" = CI
          )

        browser()
        # Merge Mean and CI columns
        data_table <- data_table %>%
          unite(methods_dict[[method]][[posterior_key]]$parameter_notation, "Posterior Parameter", 'Confidence Interval', sep = " ")


        # # Create the plot
        # plt <- ggplot(combined_data, aes(x = x, y = y, ymin = conf_int_lower, ymax = conf_int_upper, color = as.factor(drift))) +
        #   geom_errorbar(width = cap_size, position = position_dodge(width = cap_size / 2)) +
        #   geom_point(size = markersize, position = position_dodge(width = cap_size / 2)) +
        #   scale_color_manual(values = color_map, name = NULL, labels = treatment_effects_names) +
        #   ggplot2::labs(
        #     title = plot_title,
        #     x = TeX(sprintf("%s %s", "Prior", methods_dict[[method]][[key]]$parameter_notation)),
        #     y = TeX(sprintf("%s %s", "Posterior", methods_dict[[method]][[posterior_key]]$parameter_notation)),
        #     color = "Target treatment effect",
        #     group = "Target treatment effect"
        #   ) +
        #   theme_bw() +
        #   theme(
        #     text = element_text(family = font, size = text_size),
        #     axis.text.y = element_text(size = text_size),
        #     axis.text.x = element_text(size = text_size),
        #     legend.key = element_blank(),
        #     strip.background = element_blank(),
        #     panel.grid.major = element_blank(),
        #     panel.grid.minor = element_blank()
        #   )

        # Save the plot as PDF and PNG
        directory <- file.path(tables_dir, case_study)
        if (!dir.exists(directory)) {
          dir.create(directory,
                     showWarnings = FALSE,
                     recursive = TRUE)
        }

        filename <- paste0(
          case_study,
          "_posterior_",
          methods_dict[[method]][[posterior_key]]$parameter_label,
          "_vs_prior_",
          methods_dict[[method]][[key]]$parameter_label,
          "_",
          method,
          "_sample_size_",
          target_sample_size_per_arm
        )

        if (other_params_str != ""){
          filename <- paste0(filename, "_", other_params_str)
        }

        filename <- format_filename(filename = filename, case_study = case_study, target_to_source_std_ratio = target_to_source_std_ratio, source_denominator_change_factor = source_denominator_change_factor)

        file_path <- file.path(directory, filename)

        export_table(data_table = data_table, ncollapses = 1, title = title, file_path = file_path, format = c("latex", "html", "pdf"))

        browser()
      }
    }
  }
}


#' Generate multiple posterior parameter tables
#'
#' This function generates multiple tables for posterior parameters across different case studies, methods, and sample sizes.
#'
#' @param results_metrics_df A data frame containing the results metrics.
#' @param metrics A list or vector of metrics to include in the analysis.
#'
#' @return This function does not return a value. It calls other functions to create and save multiple tables.
#'
#' @import dplyr
#' @import yaml
#'
#' @export
posterior_parameters_tables <- function(results_metrics_df, metrics, source_denominator_change_factor = 1,
                                        target_to_source_std_ratio = 1) {
  # Get the list of case studies
  case_studies <- unique(results_metrics_df$case_study)

  results_metrics_df <- results_metrics_df %>%
    dplyr::filter(
      source_denominator_change_factor == !!source_denominator_change_factor  |
        is.na(source_denominator_change_factor),
      target_to_source_std_ratio == !!target_to_source_std_ratio |
        is.na(target_to_source_std_ratio)
    )

  # Get the list of methods
  methods <- unique(results_metrics_df$method)

  treatment_effects <- c("partially_consistent", "consistent")


  for (case_study in case_studies) {
    results_metrics_df1 <- results_metrics_df[results_metrics_df$case_study == case_study,]
    for (method in methods) {
      results_metrics_df2 <- results_metrics_df1[results_metrics_df1$method == method,]
      target_sample_sizes <- unique(results_metrics_df2$target_sample_size_per_arm)
      for (target_sample_size_per_arm in target_sample_sizes) {

        results_metrics_df3 <- results_metrics_df2[results_metrics_df2$target_sample_size_per_arm == target_sample_size_per_arm,]

        target_to_source_std_ratios <- unique(results_metrics_df3$target_to_source_std_ratio)

        for (target_to_source_std_ratio in target_to_source_std_ratios) {
          results_metrics_df4 <- results_metrics_df3 %>%
            dplyr::filter(
              target_to_source_std_ratio == !!target_to_source_std_ratio |
                is.na(target_to_source_std_ratio)
            )

          source_denominator_change_factors <- unique(results_metrics_df4$source_denominator_change_factor)

          for (source_denominator_change_factor in source_denominator_change_factors){
            results_metrics_df5 <- results_metrics_df4 %>%
              dplyr::filter(
                source_denominator_change_factor == !!source_denominator_change_factor |
                  is.na(source_denominator_change_factor)
              )

            # Call the posterior_parameters_vs_drift function
            table_posterior_parameters_vs_drift(
              results_metrics_df,
              method,
              case_study,
              target_sample_size_per_arm,
              control_drift = FALSE,
              xvars = xvars,
              source_denominator_change_factor = source_denominator_change_factor,
              target_to_source_std_ratio = target_to_source_std_ratio
            )
            # Call the posterior_vs_prior_parameters function
            table_posterior_vs_prior_parameters(
              results_metrics_df,
              method,
              case_study,
              target_sample_size_per_arm = target_sample_size_per_arm,
              metrics = metrics,
              source_denominator_change_factor = source_denominator_change_factor,
              target_to_source_std_ratio = target_to_source_std_ratio
            )
          }
        }
      }
    }
  }
}
