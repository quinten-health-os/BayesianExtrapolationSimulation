#' @keywords internal
#' @import dplyr tidyr readr parallel yaml zeallot purrr jsonlite tidyverse foreach
#' @import doParallel progress doSNOW cmdstanr extrafont latex2exp truncnorm roxygen2
#' @import RBesT R6 MASS HDInterval pwr ggplot2 viridis webshot2 stringr assertions
#' @import Bolstad2 gridExtra binom knitr rlang kableExtra bayesplot
"_PACKAGE"

## usethis namespace: start
#' @importFrom knitr knit
#' @importFrom knitr opts_chunk
#' @importFrom latex2exp TeX
## usethis namespace: end
NULL
