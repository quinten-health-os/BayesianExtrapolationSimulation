#' Check columns in a dataframe
#'
#' This function checks if a dataframe contains the expected columns and only the expected columns.
#'
#' @param df A dataframe to check.
#' @param expected_colnames A character vector of column names the dataframe should contain.
#'
#' @return No return value, called for side effects.
#'
#' @keywords internal
check_colnames <- function(df, expected_colnames) {
  missing_cols <- setdiff(expected_colnames, colnames(df))
  if (length(missing_cols) > 0) {
    error_message <- paste(
      "The dataframe is missing the following columns:",
      paste(missing_cols, collapse = ", ")
    )
    stop(error_message)
  }

  missing_cols <- setdiff(colnames(df), expected_colnames)
  if (length(missing_cols) > 0) {
    error_message <- paste(
      "The dataframe has unexpected columns:",
      paste(missing_cols, collapse = ", ")
    )
    stop(error_message)
  }
}

#' Remove columns from a dataframe
#'
#' This function removes specified columns from a dataframe.
#'
#' @param df A dataframe to modify.
#' @param to_remove A character vector of column names to remove.
#'
#' @return A dataframe with specified columns removed.
#'
#' @keywords internal
remove_columns_from_df <- function(df, to_remove) {
  for (key in to_remove) {
    if (key %in% colnames(df)) {
      df <- df[, -which(colnames(df) == key)]
    }
  }
  return(df)
}

#' Concatenate all simulation results to a global dataframe
#'
#' This function reads all CSV files with names starting with "results" from the specified
#' directory, concatenates them, and saves the result to a new CSV file.
#'
#' @param results_dir A character string specifying the path of the results folder.
#' @param ocs_filename A character string specifying the filename of the results dataframe.
#'
#' @return No return value, called for side effects.
#'
#' @importFrom dplyr bind_rows
#'
#' @keywords internal
concatenate_simulation_results <- function(results_dir, ocs_filename) {
  # Initialize an empty data frame to store the concatenated results
  df_results <- data.frame()

  if (grepl("frequentist", ocs_filename)) {
    ocs_type <- "frequentist"
  } else if (grepl("bayesian", ocs_filename)) {
    ocs_type <- "bayesian"
  } else {
    stop("Wrong filename defined in output config.")
  }
  folder_dir <- file.path(results_dir, ocs_type)

  # List all files in the directory tree
  files <- list.files(folder_dir, recursive = TRUE, full.names = TRUE)

  for (file_path in files) {
    if (grepl("\\.csv$", file_path)) {
      if (startsWith(basename(file_path), "results")) {
        # Read the CSV file
        df <- read.csv(file_path, stringsAsFactors = FALSE)

        # Concatenate to the global data frame
        df_results <- dplyr::bind_rows(df_results, df)
      }
    }
  }

  # Save the global data frame to a new CSV file
  readr::write_csv(df_results, file.path(results_dir, ocs_filename))
}

#' Concatenate results dataframe for several envs to a global dataframe
#'
#' This function reads all final results CSV files from the specified
#' env directory, concatenates them, and saves the result to a new CSV file.
#'
#' @param results_dir A character string specifying the path of the results folder.
#' @param ocs_filename A character string specifying the filename of the results dataframe.
#'
#' @return No return value, called for side effects.
#'
#' @importFrom dplyr bind_rows
#'
#' @keywords internal
concatenate_final_simulation_results <- function(results_dir, envs, ocs_filename) {
  # Initialize an empty data frame to store the concatenated results
  df_results <- data.frame()

  for (env in envs) {
    folder_dir <- file.path(results_dir, env)
    file_path <- file.path(folder_dir, ocs_filename)
    # Read the CSV file
    df <- read.csv(file_path, stringsAsFactors = FALSE)
    # Concatenate to the global data frame
    df_results <- dplyr::bind_rows(df_results, df)
  }

  # Save the global data frame to a new CSV file
  readr::write_csv(df_results, file.path(results_dir, ocs_filename))
}

#' Concatenate all simulation logs to a global dataframe
#'
#' This function reads all CSV files with names starting with "logs" from both the "bayesian" and
#' "frequentist" subdirectories, concatenates them, adds an "OCs" column, and saves the result to a new CSV file.
#'
#' @param results_dir A character string specifying the path of the results folder.
#'
#' @return No return value, called for side effects.
#'
#' @importFrom dplyr bind_rows select everything
#'
#' @export
concatenate_simulation_logs <- function(results_dir) {
  # Initialize an empty data frame to store the concatenated results
  df_logs <- data.frame()

  ocs_types <- c("bayesian", "frequentist")

  for (ocs_type in ocs_types) {
    folder_dir <- file.path(results_dir, ocs_type)

    # List all files in the directory tree
    files <- list.files(folder_dir, recursive = TRUE, full.names = TRUE)

    for (file_path in files) {
      if (grepl("\\.csv$", file_path)) {
        if (startsWith(basename(file_path), "logs")) {
          # Read the CSV file
          df <- read.csv(file_path, stringsAsFactors = FALSE)
          # Add OCs column
          df$OCs <- ocs_type
          # Concatenate to the global data frame
          df_logs <- dplyr::bind_rows(df_logs, df)
        }
      }
    }
  }
  # Reorder columns to place OCs column at the start
  df_logs <- df_logs %>%
    dplyr::select(OCs, everything())
  # Save the global data frame to a new CSV file
  readr::write_csv(df_logs, file.path(results_dir, "logs.csv"))
}


format_simulation_output_table <- function(output) {
  # Extract the data
  data <- list(
    "Success Probability" = c(
      output$success_proba,
      output$conf_int_success_proba_lower,
      output$conf_int_success_proba_upper
    ),
    "Coverage" = c(
      output$coverage,
      output$conf_int_coverage_lower,
      output$conf_int_coverage_upper
    ),
    "MSE" = c(
      output$mse,
      output$conf_int_mse_lower,
      output$conf_int_mse_upper
    ),
    "Bias" = c(
      output$bias,
      output$conf_int_bias_lower,
      output$conf_int_bias_upper
    ),
    "Posterior Mean" = c(
      output$posterior_mean,
      output$conf_int_posterior_mean_lower,
      output$conf_int_posterior_mean_upper
    ),
    "Posterior Median" = c(
      output$posterior_median,
      output$conf_int_posterior_median_lower,
      output$conf_int_posterior_median_upper
    ),
    "Precision" = c(
      output$precision,
      output$conf_int_precision_lower,
      output$conf_int_precision_upper
    ),
    "Credible Interval" = c(
      NA,
      output$credible_interval_lower,
      output$credible_interval_upper
    ),
    "ESS Moment" = c(
      output$ess_moment,
      output$conf_int_ess_moment_lower,
      output$conf_int_ess_moment_upper
    ),
    "ESS Precision" = c(
      output$ess_precision,
      output$conf_int_ess_precision_lower,
      output$conf_int_ess_precision_upper
    ),
    "ESS ELIR" = c(
      output$ess_elir,
      output$conf_int_ess_elir_lower,
      output$conf_int_ess_elir_upper
    )
  )

  # Create a data frame
  df <- data.frame(
    Metric = names(data),
    Value = sapply(data, `[`, 1),
    CI_Lower = sapply(data, `[`, 2),
    CI_Upper = sapply(data, `[`, 3)
  )

  # Format the values
  df$Value <- format(df$Value, digits = 4, scientific = FALSE)
  df$CI_Lower <- format(df$CI_Lower, digits = 4, scientific = FALSE)
  df$CI_Upper <- format(df$CI_Upper, digits = 4, scientific = FALSE)

  # Create the confidence interval column
  df$`95% CI` <- paste0("[", df$CI_Lower, ", ", df$CI_Upper, "]")

  # Select and rename columns
  df <- df[, c("Metric", "Value", "95% CI")]

  # Print the table
  print(df, row.names = FALSE)
}

format_parameters_to_json <- function(json_parameters, escape = FALSE) {
  json_parameters <- jsonlite::toJSON(json_parameters, pretty = TRUE)
  json_parameters <- gsub("\"", "\'", json_parameters)
  json_parameters <- as.character(json_parameters)
  if (escape == TRUE) {
    json_parameters <- paste0("[\n  ", json_parameters, "\n]")
  }
  return(json_parameters)
}


format_case_study_config <- function(case_study_config) {
  if (case_study_config$endpoint == "continuous" |
      case_study_config$endpoint == "recurrent_event") {
    data <- data.frame(
      Parameter = c(
        "Name",
        "Control",
        "Summary Measure Likelihood",
        "Theta 0",
        "Endpoint",
        "Null Space",
        "Sampling Approximation",
        "Control",
        "Treatment",
        "Total",
        "Treatment Effect",
        "Standard Error",
        "Control",
        "Treatment",
        "Total",
        "Treatment Effect",
        "Standard Error"
      ),
      Value = c(
        case_study_config$name,
        case_study_config$control,
        case_study_config$summary_measure_likelihood,
        case_study_config$theta_0,
        case_study_config$endpoint,
        case_study_config$null_space,
        case_study_config$sampling_approximation,
        case_study_config$target$control,
        case_study_config$target$treatment,
        case_study_config$target$total,
        case_study_config$target$treatment_effect,
        case_study_config$target$standard_error,
        case_study_config$source$control,
        case_study_config$source$treatment,
        case_study_config$source$total,
        case_study_config$source$treatment_effect,
        case_study_config$source$standard_error
      )
    )

    # Create the table with headers and horizontal lines
    kable(data,
          col.names = c("Parameter", "Value"),
          align = "l") %>%
      kableExtra::add_header_above(c("Case Study Configuration" = 2)) %>%
      kableExtra::kable_styling("striped", full_width = F) %>%
      kableExtra::pack_rows("General", 1, 7) %>%
      kableExtra::pack_rows("Target", 8, 12) %>%
      kableExtra::pack_rows("Source", 13, 17)
  } else if (case_study_config$endpoint == "time_to_event") {
    data <- data.frame(
      Parameter = c(
        "Name",
        "Summary Measure Likelihood",
        "Theta 0",
        "Endpoint",
        "Null Space",
        "Sampling Approximation",
        "Control (Target)",
        "Treatment (Target)",
        "Total (Target)",
        "Treatment Effect (Target)",
        "Standard Error (Target)",
        "Maximum follow-up time (Target)",
        "Control (Source)",
        "Treatment (Source)",
        "Total (Source)",
        "Treatment Effect (Source)",
        "Standard Error (Source)",
        "Maximum follow-up time (Source)"
      ),
      Value = c(
        case_study_config$name,
        case_study_config$summary_measure_likelihood,
        case_study_config$theta_0,
        case_study_config$endpoint,
        case_study_config$null_space,
        case_study_config$sampling_approximation,
        case_study_config$target$control,
        case_study_config$target$treatment,
        case_study_config$target$total,
        case_study_config$target$treatment_effect,
        case_study_config$target$standard_error,
        case_study_config$target$max_follow_up_time,
        case_study_config$source$control,
        case_study_config$source$treatment,
        case_study_config$source$total,
        case_study_config$source$treatment_effect,
        case_study_config$source$standard_error,
        case_study_config$source$max_follow_up_time
      )
    )

    # Create the table with headers and horizontal lines
    kable(data,
          col.names = c("Parameter", "Value"),
          align = "l") %>%
      kableExtra::add_header_above(c("Case Study Configuration" = 2)) %>%
      kableExtra::kable_styling("striped", full_width = F) %>%
      kableExtra::pack_rows("General", 1, 6) %>%
      kableExtra::pack_rows("Target", 7, 12) %>%
      kableExtra::pack_rows("Source", 13, 18)
  } else if (case_study_config$endpoint == "binary") {
    data <- data.frame(
      Parameter = c(
        "Name",
        "Control",
        "Summary Measure Likelihood",
        "Theta 0",
        "Endpoint",
        "Null Space",
        "Sampling Approximation",
        "Target Control",
        "Target Treatment",
        "Target Total",
        "Target Responses (Control)",
        "Target Responses (Treatment)",
        "Target Treatment Effect",
        "Target Standard Error",
        "Source Control",
        "Source Treatment",
        "Source Total",
        "Source Responses (Control)",
        "Source Responses (Treatment)",
        "Source Treatment Effect",
        "Source Standard Error"
      ),
      Value = c(
        case_study_config$name,
        case_study_config$control,
        case_study_config$summary_measure_likelihood,
        case_study_config$theta_0,
        case_study_config$endpoint,
        case_study_config$null_space,
        case_study_config$sampling_approximation,
        case_study_config$target$control,
        case_study_config$target$treatment,
        case_study_config$target$total,
        case_study_config$target$responses$control,
        case_study_config$target$responses$treatment,
        case_study_config$target$treatment_effect,
        case_study_config$target$standard_error,
        case_study_config$source$control,
        case_study_config$source$treatment,
        case_study_config$source$total,
        case_study_config$source$responses$control,
        case_study_config$source$responses$treatment,
        case_study_config$source$treatment_effect,
        case_study_config$source$standard_error
      )
    )

    # Create the table with headers and horizontal lines
    kable(data,
          col.names = c("Parameter", "Value"),
          align = "l") %>%
      kableExtra::add_header_above(c("Case Study Configuration" = 2)) %>%
      kableExtra::kable_styling("striped", full_width = F) %>%
      kableExtra::pack_rows("General", 1, 7) %>%
      kableExtra::pack_rows("Target", 8, 14) %>%
      kableExtra::pack_rows("Source", 15, 21)
  }
}


compile_stan_model <- function(model_name, stan_model_code) {
  stan_directory <- paste0(system.file("stan", package = "RBExT"), "/")
  stan_model_file_path <- paste0(stan_directory, model_name, ".stan")
  writeLines(stan_model_code, con = stan_model_file_path)
  stan_exe_file_path <- paste0(stan_directory, model_name, ".exe")

  cpp_options <- list(stan_threads = TRUE)


  if (!file.exists(stan_exe_file_path)) {
    stan_model <- cmdstanr::cmdstan_model(stan_model_file_path,
                                          exe_file = stan_exe_file_path,
                                          cpp_options = cpp_options)
  } else {
    stan_model <- cmdstanr::cmdstan_model(exe_file = stan_exe_file_path, cpp_options = cpp_options)
  }
  return(stan_model)
}

load_data <- function(results_row, type, reload_data_objects = FALSE) {
  if (reload_data_objects) {
    case_study_config <- yaml::yaml.load_file(system.file(
      paste0("conf/case_studies/", results_row$case_study, ".yml"),
      package = "RBExT"
    ))

    source_data <- SourceData$new(
      case_study_config = case_study_config,
      source_denominator = results_row$source_denominator
    )
    if (type == "target") {
      data <- TargetDataFactory$new()
      data <- data$create(
        source_data = source_data,
        case_study_config = case_study_config,
        target_sample_size_per_arm = results_row$target_sample_size_per_arm,
        treatment_drift = results_row$treatment_drift,
        control_drift = results_row$control_drift,
        summary_measure_likelihood = source_data$summary_measure_likelihood,
        target_to_source_std_ratio = results_row$target_to_source_std_ratio
      )
    } else if (type == "source") {
      data <- source_data
    }
  } else {
    if (type == "target") {
      data <- list(
        sample_size_per_arm = results_row$target_sample_size_per_arm,
        sample_size_control = results_row$target_sample_size_per_arm,
        sample_size_treatment = results_row$target_sample_size_per_arm,
        treatment_effect = results_row$target_treatment_effect,
        standard_deviation = results_row$target_standard_deviation,
        summary_measure_likelihood = results_row$summary_measure_likelihood,
        treatment_rate = results_row$target_treatment_rate,
        control_rate = results_row$target_control_rate
      )
    } else if (type == "source") {
      data <- list(
        treatment_effect_estimate = results_row$source_treatment_effect_estimate,
        standard_error = results_row$source_standard_error,
        sample_size_control = results_row$source_sample_size_control,
        sample_size_treatment = results_row$source_sample_size_treatment,
        equivalent_source_sample_size_per_arm = results_row$equivalent_source_sample_size_per_arm,
        treatment_rate = results_row$source_treatment_rate,
        control_rate = results_row$source_control_rate
      )

      if (is.null(data$equivalent_source_sample_size_per_arm) |
          any(is.na(data$equivalent_source_sample_size_per_arm))) {
        data$equivalent_source_sample_size_per_arm <- 2 * data$sample_size_control * data$sample_size_treatment / (data$sample_size_control + source_data$sample_size_treatment)
      }
    }
  }
  return(data)
}

# Function to create boolean filter
create_boolean_filter <- function(df, conditions, exclude_key = NULL) {
  if (!is.null(exclude_key)) {
    conditions <- conditions[!names(conditions) %in% exclude_key]
  }

  # Convert all columns to numeric where possible
  df <- data.frame(lapply(df, function(x)
    as.numeric(x)))


  filter <- rep(TRUE, nrow(df))
  for (col in names(conditions)) {
    condition <- conditions[[col]]
    filter <- (df[[col]] == condition) & filter
  }
  return(filter)
}


check_confidence_intervals <- function(df, metrics) {
  # Loop through each metric and check the confidence intervals
  for (metric in metrics) {
    upper_col <- paste0("conf_int_", metric, "_upper")
    lower_col <- paste0("conf_int_", metric, "_lower")

    # Check if the metric and its CI bounds exist in the dataframe
    if (all(c(metric, lower_col, upper_col) %in% names(df))) {

      # Check if the lower bound is indeed lower than the upper bound
      invalid_bounds <- which(df[[lower_col]] > df[[upper_col]])

      if (length(invalid_bounds) > 0) {
        issue <- paste0("Lower bound of the CI is larger than the upper bound for ", metric)
        warning(issue)
      }

      # Check if the metric value lies within the confidence interval
      out_of_bounds <- which(df[[metric]] < df[[lower_col]] | df[[metric]] > df[[upper_col]])
      if (length(out_of_bounds) > 0) {
        issue <- paste0("Mean value outside the CI bounds for ", metric)
        warning(issue)
      }
    }
  }
}


# Used to extract parameters as nested list
extract_nested_parameter = function(parameters){
  # Initialize an empty list to store the nested list
  nested_list <- list()

  # Iterate over the column names of the parameters to construct the nested list
  for (colname in colnames(parameters)) {

    # Split the column name by period (".") to find the hierarchy
    split_names <- strsplit(colname, "\\.")[[1]]

    if (length(split_names) == 2) {
      if (!split_names[1] %in% names(nested_list)) {
        nested_list[[split_names[1]]] <- list()
      }

      x <- parameters[[colname]]
      x_numeric <- suppressWarnings(as.numeric(x))

      # Replace NA values with the original input
      x_clean <- ifelse(is.na(x_numeric), x, x_numeric)

      # Assign values dynamically to the second level (e.g., family or std_dev)
      nested_list[[split_names[1]]][[split_names[2]]] <- x_clean

      # For 'initial_prior', assign the value directly
    } else {
      nested_list[colname] <- parameters[[colname]]
    }
  }
  return(nested_list)
}

# Function to log errors globally
global_error_handler <- function() {
  err <- geterrmessage()  # Get the error message
  futile.logger::flog.error("Global error occurred: %s", err)

  # Optionally log other debugging info such as the call stack
  futile.logger::flog.error("Call stack:\n%s", paste(deparse(sys.calls()), collapse = "\n"))

  # Log additional variables of interest (if needed)
  # For instance, if you're in a loop or a function with certain variables
  # futile.logger::flog.error("Variable state at error - x: %s, y: %s", x, y)  # Customize as needed
}

generate_log_filename <- function(base_name = "error_log.log", suffix_type = "timestamp") {
  if (!file.exists(base_name)) {
    return(base_name)  # Return the base name if no file exists
  }

  # If the file exists, create a new filename with a suffix
  if (suffix_type == "timestamp") {
    # Add a timestamp to the filename
    timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
    new_name <- sub(".log$", paste0("_", timestamp, ".log"), base_name)
  } else if (suffix_type == "counter") {
    # Use a counter to create unique filenames
    counter <- 1
    repeat {
      new_name <- sub(".log$", paste0("_", counter, ".log"), base_name)
      if (!file.exists(new_name)) break
      counter <- counter + 1
    }
  }

  return(new_name)
}

save_state <- function(iteration, scenario, worker_id = NULL, env) {
  if (is.null(worker_id)){
    file = paste0("./logs/", env, "/checkpoints/checkpoint_iter_", iteration, ".RData")
  } else {
    file = paste0("./logs/", env, "/checkpoints/checkpoint_iter_", worker_id, "_iter_", iteration, ".RData")
  }
  # Extract the directory path from the file path
  dir_path <- dirname(file)

  # Check if the directory exists, and if not, create it
  if (!file.exists(dir_path)) {
    dir.create(dir_path, recursive = TRUE)
  }

  save(scenario, file = file)
}

read_function_code <- function(function_obj){
  function_name <- substitute(function_obj)

  # Use deparse() to get the function's source code
  function_code <- deparse(function_obj)

  # Prepend the function name and assignment
  cat(paste0(function_name, " <- ", paste(function_code, collapse = "\n"), sep = ""))
}


