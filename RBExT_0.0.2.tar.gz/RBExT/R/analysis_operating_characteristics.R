#' Compute the frequentist power
#'
#' @description This function computes the power of a test for a given significance level
#' @description This function computes the power of a test for a given significance level
#'
#' @param alpha The significance level.
#' @param target_data The target data containing sample size, treatment effect, standard deviation, and summary measure distribution.
#' @param frequentist_test The type of frequentist test ("t-test" or "z-test").
#' @param theta_0 The null hypothesis value.
#' @param target_data Target data object
#' @param frequentist_test Type of frequentist test to apply, either z-test or t-test
#' @param theta_0 Boundary of the null hypothesis space
#' @param null_space Side of the null space, either left or right.
#'
#' @return The power of the test.
#'
#' @export
compute_freq_power <- function(alpha,
                               target_data,
                               frequentist_test,
                               theta_0,
                               null_space) {
  if (null_space == "left") {
    alternative <- "greater"
  } else if (null_space == "right") {
    alternative <- "less"
  } else {
    stop("Null space must be either 'left' or 'right'")
  }

  if (is.na(alpha)){
    return(NA)
  }

  assertions::assert_number(target_data$treatment_effect)
  assertions::assert_number(target_data$standard_deviation)
  assertions::assert_number(target_data$sample_size_per_arm)

  power <- NA # Default value in case of an unsupported distribution

  if (target_data$summary_measure_likelihood == "normal") {
    effect_size <- (target_data$treatment_effect - theta_0) / target_data$standard_deviation

    if (frequentist_test == "t-test") {
      # Use pwr::pwr.t.test for a t-test power calculation
      power <- pwr::pwr.t.test(
        d = effect_size,
        n = target_data$sample_size_per_arm,
        sig.level = alpha,
        type = "one.sample",
        alternative = alternative
      )$power
    } else if (frequentist_test == "z-test") {
      # Calculate the power of the z-test
      power <- pwr::pwr.norm.test(
        d = effect_size,
        n = target_data$sample_size_per_arm,
        sig.level = alpha,
        alternative = alternative
      )$power
    }
  } else if (target_data$summary_measure_likelihood == "binomial") {
    # Compute Cohen's h
    h <- pwr::ES.h(target_data$treatment_rate, target_data$control_rate)

    power <- pwr::pwr.2p2n.test(
      h = h,
      n1 = target_data$sample_size_per_arm,
      n2 = target_data$sample_size_per_arm,
      sig.level = alpha,
      alternative = "greater"
    )$power
  } else {
    stop("This likelihood is not supported.")
  }
  return(power)
}

#' Compute the frequentist power
#'
#' @description This function computes the power of a test for a pooled analysis at a given significance level
#'
#' @param alpha The significance level.
#' @param target_data The target data containing sample size, treatment effect, standard deviation, and summary measure distribution.
#' @param source_data Source study data
#' @param frequentist_test The type of frequentist test ("t-test" or "z-test").
#' @param theta_0 The null hypothesis value.
#' @param target_data Target data object
#' @param frequentist_test Type of frequentist test to apply, either z-test or t-test
#' @param theta_0 Boundary of the null hypothesis space
#' @param null_space Side of the null space, either left or right.
#'
#' @return The power of the test.
#'
#' @export
compute_freq_power_pooling <- function(alpha,
                                       target_data,
                                       source_data,
                                       frequentist_test,
                                       theta_0,
                                       null_space) {
  if (null_space == "left") {
    alternative <- "greater"
  } else if (null_space == "right") {
    alternative <- "less"
  } else {
    stop("Null space must be either 'left' or 'right'")
  }

  assertions::assert_number(target_data$treatment_effect)
  assertions::assert_number(target_data$standard_deviation)
  assertions::assert_number(target_data$sample_size_per_arm)

  power <- NA # Default value in case of an unsupported distribution

  if (target_data$summary_measure_likelihood == "normal") {
    target_treatment_effect_standard_error <- target_data$standard_deviation / sqrt(target_data$sample_size_per_arm)

    pooled_treatment_effect <- (
      source_data$treatment_effect_estimate / (
        source_data$standard_error ^ 2 / target_treatment_effect_standard_error ^
          2 + 1
      )
    ) + (
      target_data$treatment_effect / (
        1 + target_treatment_effect_standard_error ^ 2 / source_data$standard_error ^
          2
      )
    )


    pooled_standard_error_2 <- 1 / (1 / source_data$standard_error ^ 2 + 1 / target_treatment_effect_standard_error ^
                                      2)

    pooled_variance <- pooled_standard_error_2 * (
      target_data$sample_size_per_arm + source_data$equivalent_source_sample_size_per_arm
    )

    effect_size <- (pooled_treatment_effect - theta_0) / sqrt(pooled_variance)


    if (frequentist_test == "t-test") {
      # Use pwr::pwr.t.test for a t-test power calculation
      power <- pwr::pwr.t.test(
        d = effect_size,
        n = target_data$sample_size_per_arm + source_data$equivalent_source_sample_size_per_arm,
        sig.level = alpha,
        type = "one.sample",
        alternative = alternative
      )$power
    } else if (frequentist_test == "z-test") {
      # Calculate the power of the z-test
      power <- pwr::pwr.norm.test(
        d = effect_size,
        n = target_data$sample_size_per_arm + source_data$equivalent_source_sample_size_per_arm,
        sig.level = alpha,
        alternative = alternative
      )$power
    }
  } else if (target_data$summary_measure_likelihood == "binomial") {
    pooled_sample_size_treatment <- target_data$sample_size_per_arm + source_data$sample_size_treatment
    treatment_rate_pooled <- (
      target_data$treatment_rate * target_data$sample_size_per_arm + source_data$treatment_rate * source_data$sample_size_treatment
    ) / (pooled_sample_size_treatment)

    pooled_sample_size_control <- target_data$sample_size_per_arm + source_data$sample_size_control
    control_rate_pooled <- (
      target_data$control_rate * target_data$sample_size_per_arm + source_data$control_rate * source_data$sample_size_control
    ) / (pooled_sample_size_control)

    # Compute Cohen's h
    h <- pwr::ES.h(treatment_rate_pooled, control_rate_pooled)
    power <- pwr::pwr.2p2n.test(
      h = h,
      n1 = pooled_sample_size_treatment,
      n2 = pooled_sample_size_control,
      sig.level = alpha,
      alternative = "greater"
    )$power
  } else {
    stop("This likelihood is not supported.")
  }

  assertions::assert_number(power)
  return(power)
}

#' Compute the frequentist power at equivalent tie
#'
#' @description This function computes the frequentist power at equivalent tie for a given set of results and analysis configuration.
#'
#' @param results The results data frame.
#' @param analysis_config The analysis configuration.
#'
#' @return The final results data frame with power and frequentist test columns added.
#'
#' @export
frequentist_power_at_equivalent_tie <- function(results, analysis_config) {
  if (nrow(results) == 0) {
    stop("The results dataframe is empty.")
  }

  # Remove the tie, mcse_tie, conf_int_tie_lower and conf_int_tie_upper if they exist
  results <- results[, !(
    names(results) %in% c(
      "tie",
      "mcse_tie",
      "conf_int_tie_lower",
      "conf_int_tie_upper"
    )
  )]

  matching_columns <- c(
    "method",
    "parameters",
    "control_drift",
    "source_denominator",
    "source_denominator_change_factor",
    "case_study",
    "target_to_source_std_ratio",
    "parallelization",
    "target_sample_size_per_arm",
    "theta_0",
    "null_space",
    "sampling_approximation",
    "summary_measure_likelihood",
    "source_sample_size_treatment",
    "source_sample_size_control",
    "endpoint",
    "source_standard_error",
    "source_treatment_effect_estimate",
    "equivalent_source_sample_size_per_arm"
  )

  results_freq_df_tie <- results[results$target_treatment_effect == results$theta_0, c(
    matching_columns,
    c(
      "success_proba",
      "mcse_success_proba",
      "conf_int_success_proba_lower",
      "conf_int_success_proba_upper"
    )
  )]

  results_freq_df_tie <- results_freq_df_tie %>%
    dplyr::rename(
      tie = success_proba,
      mcse_tie = mcse_success_proba,
      conf_int_tie_lower = conf_int_success_proba_lower,
      conf_int_tie_upper = conf_int_success_proba_upper
    )

  results <- dplyr::left_join(results, results_freq_df_tie, by = matching_columns)


  # Progress bar function in R
  progress_bar <- function(n) {
    pb <- txtProgressBar(min = 0,
                         max = n,
                         style = 3)
    return(function(i) {
      setTxtProgressBar(pb, i)
    })
  }

  frequentist_test <- analysis_config[["frequentist_test"]]
  # Iterate through rows and compute power
  for (i in seq_len(nrow(results))) {
    target_data <- load_data(results[i, ],
                             type = "target",
                             reload_data_objects = TRUE)

    results$frequentist_power_at_equivalent_tie[i] <- compute_freq_power(
      results$tie[i],
      target_data,
      frequentist_test,
      results$theta_0[i],
      results$null_space[i]
    )

    results$frequentist_power_at_equivalent_tie_lower[i] <- compute_freq_power(
      results$conf_int_tie_lower[i],
      target_data,
      frequentist_test,
      results$theta_0[i],
      results$null_space[i]
    )

    results$frequentist_power_at_equivalent_tie_upper[i] <- compute_freq_power(
      results$conf_int_tie_upper[i],
      target_data,
      frequentist_test,
      results$theta_0[i],
      results$null_space[i]
    )

    results$frequentist_test[i] <- frequentist_test

    # Update progress bar
    pb <- progress_bar(nrow(results))(i)
  }

  # Merge tie and power columns to the results
  final_results <- merge(results, results)

  return(final_results)
}


frequentist_power_at_nominal_tie <- function(results, analysis_config) {
  if (nrow(results) == 0) {
    stop("The results dataframe is empty.")
  }

  nominal_tie <- analysis_config[["nominal_tie"]]
  frequentist_test <- analysis_config[["frequentist_test"]]

  # Initialize the new columns
  results$nominal_frequentist_power_separate <- NA
  results$nominal_frequentist_power_pooling <- NA

  # Initialize the new columns
  results$nominal_frequentist_power_separate <- NA
  results$nominal_frequentist_power_pooling <- NA

  # Progress bar function in R
  progress_bar <- function(n) {
    pb <- txtProgressBar(min = 0,
                         max = n,
                         style = 3)
    return(function(i) {
      setTxtProgressBar(pb, i)
    })
  }

  # Iterate through rows and compute power
  for (i in seq_len(nrow(results))) {
    target_data <- load_data(results[i, ],
                             type = "target",
                             reload_data_objects = TRUE)
    source_data <- load_data(results[i, ],
                             type = "source",
                             reload_data_objects = TRUE)

    nominal_frequentist_power_separate <- compute_freq_power(
      alpha = nominal_tie,
      target_data = target_data,
      frequentist_test = frequentist_test,
      theta_0 = results$theta_0[i],
      null_space = results$null_space[i]
    )

    results$nominal_frequentist_power_separate[i] <- nominal_frequentist_power_separate

    nominal_frequentist_power_pooling <- compute_freq_power_pooling(
      alpha = nominal_tie,
      target_data = target_data,
      source_data = source_data,
      frequentist_test = frequentist_test,
      theta_0 = results$theta_0[i],
      null_space = results$null_space[i]
    )

    results$nominal_frequentist_power_pooling[i] <- nominal_frequentist_power_pooling

    # Update progress bar
    pb <- progress_bar(nrow(results))(i)
  }
  return(results)
}
