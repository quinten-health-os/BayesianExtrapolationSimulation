#' Create a forest plot
#'
#' @description This function creates a forest plot using the provided data.
#'
#' @param data The data for creating the forest plot.
#' @param title The title of the forest plot.
#' @param ylabel A logical value indicating whether to display the y-axis label.
#' @param x_metric_name Name of the metric on the x-axis
#' @param sweet_spot_lower Lower limit of the metric on the x-axis
#' @param sweet_spot_upper Upper limit of the metric on the x-axis
#' @param x_metric_label Label of the metric on the x-axis
#'
#' @return A ggplot2::ggplot( object representing the forest plot.
#' @keywords internal
forest_subplot_sweet_spot <- function(data,
                           title,
                           sweet_spot_lower,
                           sweet_spot_upper,
                           x_range,
                           x_metric_label,
                           methods_labels,
                           legend = FALSE) {

  # Make sure that the data are sorted according to the parameters values
  for (method in unique(data$method)) {
    if (method == "separate"){
      next
    }else {
      data_subset <- data[data$method == method, ]
      params <- get_parameters(data_subset[, "parameters"])

      column_names <- colnames(params)
      sorted_index <- do.call(order, lapply(params[column_names], as.factor))

      # Reorder the data :
      data[data$method == method, ] <- data_subset[sorted_index, ]
    }
  }

  labels <- sapply(1:nrow(data), function(i) {
    process_method_parameters_label(data[i, ], methods_labels)
  })

  data$rows <- seq(1, nrow(data))

  plt <- ggplot2::ggplot(
    data,
    ggplot2::aes(
      y = rows,
      x = !!sweet_spot_lower,
      xmin = !!sweet_spot_lower,
      xmax = !!sweet_spot_upper
    )
  ) +
    geom_errorbarh(height = 0.2) +
    ggplot2::labs(title = title, x = "Drift", y = NULL) +
    theme(
      axis.title.y = element_blank(),
      text = element_text(family = font, size = text_size),
      axis.text.y = element_text(size = text_size),
      strip.text.x = element_text(size = text_size),
      legend.key = element_blank(),
      strip.background = element_blank(),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.title = element_text(size = text_size),
      plot.title = element_text(hjust = 0.5),
      plot.background = element_blank()
    ) +
    scale_y_continuous(breaks = data$rows, labels = labels)

  # plt <- plt + scale_x_continuous(limits = c(x_range[[1]] - 0.01, x_range[[2]] + 0.01))
  return(plt)
}


#' Generate a forest plot
#'
#' @description This function generates a forest plot based on the provided results dataframe, selected case study, and selected target sample size per arm.
#'
#' @param results_freq_df The results dataframe.
#' @param selected_case_study The selected case study.
#' @param selected_target_sample_size_per_arm The selected target sample size per arm.
#' @param x_metric Metric on the x-axis
#'
#' @return None
forest_plot_sweet_spot <- function(results_freq_df, x_metric) {
  selected_case_study <- unique(results_freq_df$case_study)
  selected_target_sample_size_per_arm <- unique(results_freq_df$target_sample_size_per_arm)


  directory <- file.path(figures_dir, selected_case_study)

  if (!dir.exists(directory)) {
    dir.create(directory, showWarnings = FALSE, recursive = TRUE)
  }

  if (x_metric %in% names(frequentist_metrics)) {
    metric <- frequentist_metrics[[x_metric]]
    metric$label = paste0("Sweet spot relative to ", metric$label)
  } else if (x_metric %in% names(inference_metrics)) {
    metric <- inference_metrics[[x_metric]]
  } else if (x_metric %in% names(bayesian_metrics)) {
    metric <- bayesian_metrics[[x_metric]]
  } else {
    if (x_metric == "TIE_smaller_than_nominal"){
      metric = frequentist_metrics[["tie"]]
      metric$name <- "TIE_smaller_than_nominal"
      metric$label <- "TIE vs nominal TIE"
    } else if (x_metric == "power_larger_than_nominal"){
      metric = frequentist_metrics[["power"]]
      metric$name <- "power_larger_than_nominal"
      metric$label <- "Power vs nominal power"
    } else {
      stop("Metric is not supported")
    }
  }

  id_cols <- c("method", "parameters", "target_sample_size_per_arm", "control_drift", "source_denominator", "source_denominator_change_factor", "case_study", "parallelization", "sampling_approximation", "source_treatment_effect_estimate",  "target_to_source_std_ratio", "theta_0", "null_space", "summary_measure_likelihood", "source_standard_error", "source_sample_size_control", "source_sample_size_treatment", "equivalent_source_sample_size_per_arm", "endpoint", "source_control_rate", "source_treatment_rate")

  results_freq_df <- results_freq_df %>%
    pivot_wider(id_cols = id_cols, names_from = metric, values_from = c("sweet_spot_lower", "sweet_spot_upper", "sweet_spot_width", "drift_range_upper", "drift_range_lower"))

  if (!(paste0("sweet_spot_width_", metric$name) %in% colnames(results_freq_df))) {
    warning("Metric not in input dataframe.")
    return()
  }


  sweet_spot_lower <- rlang::sym(paste0("sweet_spot_lower_", metric$name))
  sweet_spot_upper <- rlang::sym(paste0("sweet_spot_upper_", metric$name))
  x_metric_label <- metric$label

  round_decimal <- 4

  df <- results_freq_df %>%
    dplyr::mutate(
      lower_bound = !!sweet_spot_lower,
      lower_bound = !!sweet_spot_upper
    )

  title <- sprintf(
    "%s, %s, $N_T/2 = $ %s",
    x_metric_label,
    str_to_title(unique(df$case_study)),
    unique(df$target_sample_size_per_arm)
  )

  title <- format_title(title = title, case_study = unique(df$case_study), target_to_source_std_ratio = unique(df$target_to_source_std_ratio), source_denominator_change_factor = unique(df$source_denominator_change_factor))

  x_range = c(unique(df[,paste0("drift_range_lower_", metric$name)]), unique(df[,paste0("drift_range_upper_", metric$name)]))

  # Create forest plots for each effect
  plt <- forest_subplot_sweet_spot(
    df,
    title,
    sweet_spot_lower,
    sweet_spot_upper,
    x_range = x_range,
    x_metric_label = x_metric_label,
    methods_labels = methods_labels,
    legend = FALSE
  )

  x_metric_name <- rlang::sym(paste0("sweet_spot_", metric$name))
  filename <- paste0(
    selected_case_study,
    "_",
    x_metric_name,
    "_forest_plot_sweet_spot_target_sample_size_per_arm_",
    selected_target_sample_size_per_arm
  )

  file_path <- file.path(directory, filename)

#
#   # Convert to grobs
#   grob_no_effect <- ggplotGrob(plot_no_effect)
#   grob_partially_consistent_effect <- ggplotGrob(plot_partially_consistent_effect)
#   grob_consistent_effect <- ggplotGrob(plot_consistent_effect)
#
#   grid.newpage()

  # Note that adding the Tikz export to the export_plots function does not work.
  if (plots_to_latex == TRUE) {
    tikzDevice::tikz(file = paste0(file_path, ".tex"), width = 5.92)
  }

  # plt <- gridExtra::grid.arrange(
  #   grob_no_effect,
  #   grob_partially_consistent_effect,
  #   grob_consistent_effect,
  #   ncol = 3,
  #   widths = c(0.44, 0.25, 0.31)
  # )
  if (plots_to_latex == TRUE) {
    dev.off()
  }

  plot_size <- set_size(textwidth)
  fig_width_in <- plot_size[1]
  fig_height_in <- plot_size[2]

  export_plots(plt, file_path, fig_width_in, fig_height_in, type = "pdf")
  export_plots(plt, file_path, fig_width_in, fig_height_in, type = "png")
}


#' Plot methods comparison
#'
#' @description This function plots the comparison of methods based on the provided results metrics dataframe.
#'
#' @param sweet_spots_df The results metrics dataframe.
#' @param metrics Metrics for which to create forest plots.
#'
#' @return None
forest_plot_sweet_spots_comparison <- function(sweet_spots_df, metrics) {

  case_studies <- unique(sweet_spots_df$case_study)

  sweet_spots_df <- sweet_spots_df[(sweet_spots_df[, "source_denominator_change_factor"] == 1 &
                                              !is.na(sweet_spots_df[, "source_denominator_change_factor"])), ]

  for (metric in unique(sweet_spots_df$metric)) {
    for (case_study in case_studies) {
      sweet_spots_df1 <- sweet_spots_df[sweet_spots_df$case_study == case_study,]

      target_sample_sizes <- unique(sweet_spots_df1$target_sample_size_per_arm)
      for (target_sample_size_per_arm in target_sample_sizes) {
        sweet_spots_df2 <- sweet_spots_df1[sweet_spots_df1$target_sample_size_per_arm == target_sample_size_per_arm,]

        target_to_source_std_ratios <- unique(sweet_spots_df2$target_to_source_std_ratio)

        for (target_to_source_std_ratio in target_to_source_std_ratios) {
          sweet_spots_df3 <- sweet_spots_df2 %>%
            dplyr::filter(
              target_to_source_std_ratio == !!target_to_source_std_ratio |
                is.na(target_to_source_std_ratio)
            )

          source_denominator_change_factors <- unique(sweet_spots_df3$source_denominator_change_factor)

          for (source_denominator_change_factor in source_denominator_change_factors){
            sweet_spots_df4 <- sweet_spots_df3 %>%
              dplyr::filter(
                source_denominator_change_factor == !!source_denominator_change_factor |
                  is.na(source_denominator_change_factor)
              )
            forest_plot_sweet_spot(sweet_spots_df4, metric)
          }
        }
      }
    }
  }
}
