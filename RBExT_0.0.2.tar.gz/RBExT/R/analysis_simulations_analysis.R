#' Perform Simulation Analysis
#'
#' @description This function performs a simulation analysis for a given environment using the specified
#' analysis configuration and configuration directory. It reads the output configuration,
#' loads results, applies frequentist power analysis, and computes the sweet spot.
#'
#' @param env A character string specifying the environment for the analysis (e.g., "development", "production").
#' @param analysis_config A list containing the analysis configuration parameters.
#' @param config_dir A character string specifying the directory containing the configuration files.
#' @param frequentist_metrics List of frequentist metrics.
#'
#' @return This function does not return a value. It writes the results and sweet spot analysis
#' to CSV files in the specified results directory.
#'
#' @importFrom yaml read_yaml
#' @importFrom readr read_csv write_csv
#'
#' @export
simulation_analysis <- function(env,
                                analysis_config,
                                config_dir,
                                frequentist_metrics) {
  futile.logger::flog.info("Starting the analysis of results in environment %s", env)

  results_dir <- paste0("./results/", env)
  outputs_config <- yaml::read_yaml(system.file("conf/outputs_config.yml", package = "RBExT"))

  freq_filename <- paste0(results_dir,
                          "/",
                          outputs_config$frequentist_ocs_results_filename)

  # Load the results and apply frequentist_power_at_equivalent_tie
  results_freq_df <- readr::read_csv(freq_filename)

  if (nrow(results_freq_df) == 0) {
    stop("Results dataframe is empty.")
  }

  results_freq_df <- frequentist_power_at_equivalent_tie(results_freq_df, analysis_config)

  write_csv(results_freq_df, freq_filename)

  results_freq_df <- frequentist_power_at_nominal_tie(results_freq_df, analysis_config)

  write_csv(results_freq_df, freq_filename)

  sweet_spot_df <- sweet_spot(results_freq_df, frequentist_metrics)

  write_csv(sweet_spot_df, paste0(results_dir, "/sweet_spot.csv"))


  # Compute Bayesian OCs (in a deterministic manner) based on the results
  results_bayesian_ocs <- compute_bayesian_ocs(results_freq_df, env)
  bayes_filename <- paste0(results_dir,
                           "/",
                           outputs_config$bayesian_ocs_deterministic_results_filename)
  readr::write_csv(results_bayesian_ocs, bayes_filename)
}
