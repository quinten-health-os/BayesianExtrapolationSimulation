# Contributing Guidelines

This page explains how you can contribute to the development of the RBExT package, from reporting bugs to submitting pull requests. 
RBExT is developed on GitHub using the Git version control system. The preferred way to contribute to RBExT is to fork the main repository on GitHub, then submit a pull request (PR).
 

## Table of Contents

1. [Getting Started](#getting-started)
2. [How to Contribute](#how-to-contribute)
    - [Reporting Bugs](#reporting-bugs)
    - [Suggesting Enhancements](#suggesting-enhancements)
    - [Submitting Pull Requests](#submitting-pull-requests)
3. [Development Workflow](#development-workflow)
4. [Style Guide](#style-guide)
5. [License](#license) 

## Getting Started

1. **Fork the repository**: Click the "Fork" button at the top right of this repository and clone your fork to your local machine.

```bash
git clone https://github.com/quintengroup/RBExT
cd RBExT
```

2. **Set up the development environment**: Ensure you have R and necessary tools installed. Install the package dependencies.

    ```r
    install.packages(c("devtools", "roxygen2", "testthat", "knitr"))
    devtools::load_all()
    ```

3. **Create a branch**: Create a new branch for your feature or bugfix.

    ```bash
    git checkout -b feature/your-feature-name
    ```

## How to Contribute

### Reporting Bugs

If you find a bug in the project, please report it by opening an issue on GitHub. Include the following details:

- A clear and descriptive title
- A detailed description of the problem
- Steps to reproduce the issue
- Expected and actual results
- Any relevant screenshots or code

### Suggesting Enhancements

We welcome suggestions for new features or improvements. To suggest an enhancement, open an issue with the following information:

- A clear and descriptive title
- A detailed description of the proposed enhancement
- Any code examples or mockups
- Benefits of the enhancement

### Submitting Pull Requests

Before submitting a pull request (PR), ensure your changes are well-tested and documented. Follow these steps:

1. **Sync with the main repository**: Ensure your fork is up-to-date with the main repository.

    ```bash
    git fetch upstream
    git checkout main
    git merge upstream/main
    ```

2. **Make your changes**: Implement your feature or bugfix on your branch.

3. **Run tests**: Ensure all tests pass and write new tests if necessary.

    ```r
    devtools::test()
    ```

4. **Document your changes**: Update the documentation to reflect your changes. Ensure the README, vignettes, and any relevant documentation are updated.

5. **Commit your changes**: Write clear and concise commit messages.

    ```bash
    git add .
    git commit -m "Description of your changes"
    ```

6. **Push your branch**: Push your changes to your fork.

    ```bash
    git push origin feature/your-feature-name
    ```

7. **Open a Pull Request**: Go to the main repository and open a pull request. Provide a detailed description of your changes and link to any relevant issues.

## Development Workflow

1. **Code**: Write clear, concise, and modular code. Ensure your code adheres to the style guide.
2. **Test**: Write tests for your code to ensure it works as expected. Use the `testthat` package for unit testing.
3. **Document**: Use `roxygen2` to document your functions and maintain clear, user-friendly documentation.
4. **Review**: Submit your code for review via a pull request. Address any feedback and make necessary changes.

## Developer guide

Clone the repository from GitHub. 

To use the package in developer mode: 

```
devtools::load_all()
```

To render vignettes manually :
```
devtools::install()
rmarkdown::render("vignettes/subdirectory/vignette_name.Rmd") 
```
For example: 
```
devtools::install()
rmarkdown::render("vignettes/simulation/simulation_illustration_high_level.Rmd")
rmarkdown::render("vignettes/replications/Belimumab_replication.Rmd")
```

To render all vignettes:
```
source("./RBExT/inst/scripts/knit_vignettes.R", echo=TRUE)

```


To test the package: 
```
devtools::check()
```

To run the unit tests:
```
devtools::test()
```

To build the package: 
```
devtools::build()
```

To build the documentation website 
```
pkgdown::build_site()
```

To build the reference manual :
```
devtools::build_manual()
```

To run pipeline tests as well as plots and tables generation tests, run tests scripts in the tests folder.


Please check your code coverage using: 

install.packages("covr")
library(covr)
cov <- package_coverage()
print(cov)
report(cov)

## Style Guide

Follow the Tidyverse style guide for R code:

- Use 2 spaces for indentation.
- Use descriptive variable and function names.
- Write functions that do one thing and do it well.
- Use `snake_case` for variable names and `CamelCase` for function names.
- Limit line length to 80 characters.

## License

By contributing to [Your Statistics Package], you agree that your contributions will be licensed under the [MIT License](LICENSE).
 
