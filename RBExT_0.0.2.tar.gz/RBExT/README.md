# R Bayesian Extrapolation Tool

A collection of R tools to :

- Study frequentist and Bayesian operating characteristics of clinical trial designs leveraging Bayesian partial extrapolation (aka borrowing).
- Analyze clinical trial data using Bayesian partial extrapolation methods.

Copyright 2024 Quinten Health, under exclusive licence to the European Medicines Agency. Sharing and distribution are prohibited.

- Core contributor: Tristan Fauvel
- Contributors: Pascal Godbillot
- Project management: Marie Génin
- Leads: Julien Tanniou, Billy Amzal
- Sponsors: European Medicines Agency, Quinten Health

## Quick start

### Installation

Download the latest release. 

You can then install the RBExT package by running :

```
install.packages("/path/to/RBExT_0.0.1.tar.gz", repos = NULL, type = "source")
```

and load it using:
```
library(RBExT)
```


### Running and analyzing simulations

- To launch a simulation study, run main.R

- To plot the results of the simulation study, run plots.R

- To create the results tables, run tables.R


## Design logic

There are three main objects in the simulation framework: source data, target data, and models.
Source data are defined based on the case study configuration. Target data depend on the source data, and the specific scenario (drift, sample size). Models correspond to specific methods, and depend on the source data. They implement methods to estimate their operating characteristics. The target data objects implement a sample method, allowing to sample many replicates of the target study.

## Access documentation

To access documentation :
browseURL("docs/index.html")

## Methods and configurations requiring MCMC inference

MCMC inference with Stan is used in the following scenarios :

- RMP x aprepitant
- separate x aprepitant
- pooling x aprepitant
- conditional_power_prior x aprepitant

When using MCMC inference, the method inherits from the MCMCModel class. The initialize() method contains a string with the Stan code. This code is saved in a temporary Stan file which is used to compile the model (using `self$stan_model <- cmdstanr::cmdstan_model(stan_file_path)`). At inference

### Comparison with existing packages

- psborrow2 implements Bayesian dynamic borrowing in scenarios where a two-arm RCT is supplemented with external data on the control arm.

- RBEsT focuses on meta-analytic and mixture models

## Contributing

New contributors are always welcome. Please have a look at the [contribution guidelines](CONTRIBUTING.md) on how to get started and to make sure your code complies with our guidelines. 

